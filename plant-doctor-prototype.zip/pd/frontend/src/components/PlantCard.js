import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { COLORS, RADIUS, SHADOW, SPACING, TYPE } from '../utils/constants';
import HealthScoreBadge from './HealthScoreBadge';

export default function PlantCard({ plant, onPress }) {
  const lowConfidenceId = !plant.identifyIsDemo && plant.identifyConfidence != null && plant.identifyConfidence < 0.6;

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.9}>
      <View style={styles.thumb}>
        {plant.photoUrl ? (
          <Image source={{ uri: plant.photoUrl }} style={styles.image} />
        ) : (
          <Text style={styles.emoji}>🌿</Text>
        )}
      </View>
      <View style={styles.info}>
        <Text style={styles.name} numberOfLines={1}>{plant.name}</Text>
        <Text style={styles.species} numberOfLines={1}>
          {plant.species}
          {(plant.identifyIsDemo || lowConfidenceId) && <Text style={styles.unverified}>  · unverified ID</Text>}
        </Text>
        <HealthScoreBadge score={plant.healthScore ?? 0} isEstimate={plant.healthScoreIsEstimate !== false} />
      </View>
      <Text style={styles.chevron}>›</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    backgroundColor: COLORS.card,
    borderRadius: RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.md,
    alignItems: 'center',
    ...SHADOW.card,
  },
  thumb: {
    width: 60, height: 60, borderRadius: RADIUS.md,
    backgroundColor: COLORS.primaryLight,
    alignItems: 'center', justifyContent: 'center', marginRight: SPACING.md,
    overflow: 'hidden',
  },
  image: { width: 60, height: 60 },
  emoji: { fontSize: 28 },
  info: { flex: 1, gap: 5 },
  name: { ...TYPE.subtitle, color: COLORS.text },
  species: { fontSize: 12.5, color: COLORS.subtext, fontStyle: 'italic' },
  unverified: { color: COLORS.warning, fontStyle: 'normal', fontWeight: '700' },
  chevron: { fontSize: 22, color: COLORS.faint, marginLeft: SPACING.xs },
});
