import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { RADIUS, SPACING, TYPE, healthLabelFor } from '../utils/constants';

export default function HealthScoreBadge({ score, isEstimate = true }) {
  const { label, color } = healthLabelFor(score);
  return (
    <View style={[styles.badge, { backgroundColor: color + '1a', borderColor: color + '55' }]}>
      <View style={[styles.dot, { backgroundColor: color }]} />
      <Text style={[styles.text, { color }]}>
        {label} · {score}
        {isEstimate ? <Text style={styles.estimateTag}>  (estimate)</Text> : null}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderRadius: RADIUS.pill,
    paddingVertical: 5,
    paddingHorizontal: SPACING.md,
    alignSelf: 'flex-start',
  },
  dot: { width: 6, height: 6, borderRadius: 3 },
  text: { ...TYPE.caption, fontWeight: '700' },
  estimateTag: { fontWeight: '500', opacity: 0.75 },
});
