import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORS, RADIUS, SPACING, TYPE, confidenceLabelFor } from '../utils/constants';

/**
 * Shows how sure the app actually is about an AI-derived result (species
 * match, disease finding, etc). Never render a confidence number yourself —
 * route it through here so the wording and color stay consistent and honest
 * everywhere they appear.
 */
export default function ConfidenceNote({ confidence, isDemo, caption }) {
  if (isDemo) {
    return (
      <View style={[styles.wrap, { backgroundColor: COLORS.warningLight, borderColor: COLORS.warning }]}>
        <Text style={[styles.dot, { color: COLORS.warning }]}>●</Text>
        <View style={{ flex: 1 }}>
          <Text style={[styles.label, { color: COLORS.warning }]}>Sample data, not a real match</Text>
          {caption ? <Text style={styles.caption}>{caption}</Text> : null}
        </View>
      </View>
    );
  }

  const { pct, label, color, bg } = confidenceLabelFor(confidence);

  return (
    <View style={[styles.wrap, { backgroundColor: bg, borderColor: color }]}>
      <View style={styles.meterTrack}>
        <View style={[styles.meterFill, { width: `${Math.max(pct, 4)}%`, backgroundColor: color }]} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[styles.label, { color }]}>{label}{pct ? ` · ${pct}%` : ''}</Text>
        {caption ? <Text style={styles.caption}>{caption}</Text> : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    borderWidth: 1,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
  },
  dot: { fontSize: 10 },
  meterTrack: {
    width: 40,
    height: 6,
    borderRadius: 3,
    backgroundColor: 'rgba(0,0,0,0.08)',
    overflow: 'hidden',
  },
  meterFill: { height: '100%', borderRadius: 3 },
  label: { ...TYPE.caption, fontWeight: '700' },
  caption: { ...TYPE.caption, color: COLORS.subtext, marginTop: 2 },
});
