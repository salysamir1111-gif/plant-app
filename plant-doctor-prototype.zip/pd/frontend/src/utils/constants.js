export const COLORS = {
  primary: '#2f7a4d',
  primaryDark: '#205836',
  primaryLight: '#e6f2ea',
  accent: '#4caf7d',
  danger: '#c94a3f',
  dangerLight: '#faeae8',
  warning: '#c8801a',
  warningLight: '#fbf0e0',
  info: '#3f7fbf',
  infoLight: '#e9f1fa',
  text: '#1a2420',
  subtext: '#66756d',
  faint: '#98a29c',
  background: '#f4f8f5',
  card: '#ffffff',
  border: '#e3e9e2',
  overlay: 'rgba(16, 26, 20, 0.55)',
};

// A small, consistent scale so every screen shares the same rhythm instead
// of one-off pixel values.
export const SPACING = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 };

export const RADIUS = { sm: 10, md: 14, lg: 20, pill: 999 };

export const SHADOW = {
  card: {
    shadowColor: '#0f1f14',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 2,
  },
  floating: {
    shadowColor: '#0f1f14',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.14,
    shadowRadius: 18,
    elevation: 6,
  },
};

export const TYPE = {
  display: { fontSize: 28, fontWeight: '800', letterSpacing: -0.3 },
  title: { fontSize: 20, fontWeight: '800', letterSpacing: -0.2 },
  subtitle: { fontSize: 15, fontWeight: '700' },
  body: { fontSize: 14.5, fontWeight: '400', lineHeight: 21 },
  caption: { fontSize: 12.5, fontWeight: '500' },
  label: { fontSize: 11, fontWeight: '700', letterSpacing: 0.6 },
};

export const NOTIFICATION_MODES = {
  FULL: 'full',        // all reminders (watering, disease alerts, weekly digest)
  DIGEST: 'digest',    // gentle weekly summary only
  OFF: 'off',          // on-demand check-up mode only, no pushes
};

export const HEALTH_SCORE_LABELS = {
  90: { label: 'Thriving', color: '#2f7a4d' },
  70: { label: 'Healthy', color: '#4caf7d' },
  50: { label: 'Needs attention', color: '#c8801a' },
  0:  { label: 'At risk', color: '#c94a3f' },
};

export function healthLabelFor(score) {
  const thresholds = Object.keys(HEALTH_SCORE_LABELS).map(Number).sort((a, b) => b - a);
  for (const t of thresholds) {
    if (score >= t) return HEALTH_SCORE_LABELS[t];
  }
  return HEALTH_SCORE_LABELS[0];
}

// --- Honesty helpers -------------------------------------------------
// Centralizes how we talk about AI confidence so no screen ever states a
// guess as settled fact. Every identification/diagnosis in the app should
// route its wording through here rather than inventing its own phrasing.

export function confidenceLabelFor(confidence) {
  const pct = Math.round((confidence ?? 0) * 100);
  if (confidence >= 0.85) {
    return { pct, tier: 'high', label: 'High confidence', color: COLORS.primary, bg: COLORS.primaryLight };
  }
  if (confidence >= 0.6) {
    return { pct, tier: 'medium', label: 'Fairly confident', color: COLORS.warning, bg: COLORS.warningLight };
  }
  if (confidence > 0) {
    return { pct, tier: 'low', label: 'Low confidence — please double-check', color: COLORS.danger, bg: COLORS.dangerLight };
  }
  return { pct: 0, tier: 'none', label: 'Not verified', color: COLORS.faint, bg: COLORS.border };
}

// One-line, honest caption for an identification result, meant to sit right
// under the species name wherever it's shown.
export function identificationCaption({ isDemo, confidence }) {
  if (isDemo) {
    return 'Sample data — no plant ID service is connected yet, so this name is a placeholder, not a real match.';
  }
  const { tier, pct } = confidenceLabelFor(confidence);
  if (tier === 'high') return `${pct}% match confidence — likely correct.`;
  if (tier === 'medium') return `${pct}% match confidence — probably right, but worth a second look.`;
  if (tier === 'low') return `${pct}% match confidence — treat this as a guess until you confirm it.`;
  return 'Confidence unavailable for this match.';
}
