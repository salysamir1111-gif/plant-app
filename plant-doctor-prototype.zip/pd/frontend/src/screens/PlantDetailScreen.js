import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { COLORS, RADIUS, SHADOW, SPACING, TYPE, identificationCaption } from '../utils/constants';
import { usePlants } from '../context/PlantContext';
import HealthScoreBadge from '../components/HealthScoreBadge';
import ConfidenceNote from '../components/ConfidenceNote';
import { api } from '../services/api';

export default function PlantDetailScreen({ route, navigation }) {
  const { plantId } = route.params || {};
  const { plants, location, setPlantNotificationMode } = usePlants();
  const plant = plants.find((p) => p.id === plantId) || plants[0];
  const [schedule, setSchedule] = useState(null);
  const [scheduleFailed, setScheduleFailed] = useState(false);

  useEffect(() => {
    if (!plant) return;
    setScheduleFailed(false);
    api
      .getWateringSchedule(plant.species, location?.lat, location?.lon)
      .then(setSchedule)
      .catch(() => setScheduleFailed(true));
  }, [plant]);

  if (!plant) {
    return (
      <View style={styles.center}>
        <Text style={{ color: COLORS.subtext }}>Plant not found.</Text>
      </View>
    );
  }

  const hasIdInfo = plant.identifyIsDemo || plant.identifyConfidence != null;

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: SPACING.lg }}>
      <View style={styles.headerRow}>
        {plant.photoUrl ? (
          <Image source={{ uri: plant.photoUrl }} style={styles.hero} />
        ) : (
          <View style={[styles.hero, styles.heroPlaceholder]}>
            <Text style={{ fontSize: 40 }}>🌿</Text>
          </View>
        )}
      </View>

      <Text style={styles.name}>{plant.name}</Text>
      <Text style={styles.species}>{plant.species}</Text>
      <HealthScoreBadge score={plant.healthScore ?? 0} isEstimate={plant.healthScoreIsEstimate !== false} />

      {hasIdInfo && (
        <Section title="How sure are we about the species?">
          <ConfidenceNote
            confidence={plant.identifyConfidence ?? 0}
            isDemo={plant.identifyIsDemo}
            caption={identificationCaption({ isDemo: plant.identifyIsDemo, confidence: plant.identifyConfidence ?? 0 })}
          />
        </Section>
      )}

      <Section title="Watering schedule">
        {scheduleFailed ? (
          <Text style={styles.body}>
            Couldn't reach the watering service, so there's no schedule to show right now — check that the backend is running and try again.
          </Text>
        ) : schedule ? (
          <>
            <Text style={styles.body}>
              Water roughly every {schedule.frequencyDays} day{schedule.frequencyDays === 1 ? '' : 's'}.
              {schedule.note ? ` ${schedule.note}` : ''}
            </Text>
            {schedule.isEstimate !== false && (
              <Text style={styles.estimateCaption}>
                This is a rule-of-thumb estimate from species and local humidity, not a soil-moisture reading — adjust based on how your plant actually responds.
              </Text>
            )}
          </>
        ) : (
          <Text style={styles.body}>Loading…</Text>
        )}
      </Section>

      <Section title="Health check-up">
        <Text style={styles.body}>
          Take a photo of any leaves that look off, and we'll flag possible issues with a confidence level for each — not a guaranteed diagnosis.
        </Text>
        <TouchableOpacity
          style={styles.secondaryBtn}
          onPress={() => navigation.navigate('Camera', { mode: 'healthcheck', plantId: plant.id })}
        >
          <Text style={styles.secondaryBtnText}>📸 Run a check-up</Text>
        </TouchableOpacity>
      </Section>

      <Section title="Notifications for this plant">
        <View style={styles.modeRow}>
          {['full', 'digest', 'off'].map((mode) => (
            <TouchableOpacity
              key={mode}
              style={[styles.modeChip, plant.notificationMode === mode && styles.modeChipActive]}
              onPress={() => setPlantNotificationMode(plant.id, mode)}
            >
              <Text style={[styles.modeChipText, plant.notificationMode === mode && styles.modeChipTextActive]}>
                {mode === 'full' ? 'Full reminders' : mode === 'digest' ? 'Weekly digest' : 'On-demand only'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </Section>
    </ScrollView>
  );
}

function Section({ title, children }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  headerRow: { alignItems: 'center', marginBottom: SPACING.lg },
  hero: { width: 160, height: 160, borderRadius: RADIUS.lg, ...SHADOW.floating },
  heroPlaceholder: { backgroundColor: COLORS.primaryLight, alignItems: 'center', justifyContent: 'center' },
  name: { ...TYPE.display, fontSize: 24, color: COLORS.text, textAlign: 'center' },
  species: { fontSize: 14, color: COLORS.subtext, fontStyle: 'italic', textAlign: 'center', marginBottom: SPACING.sm },
  section: {
    marginTop: SPACING.xl, backgroundColor: COLORS.card, borderRadius: RADIUS.lg,
    padding: SPACING.lg, ...SHADOW.card,
  },
  sectionTitle: { ...TYPE.subtitle, color: COLORS.text, marginBottom: SPACING.sm },
  body: { ...TYPE.body, color: COLORS.subtext },
  estimateCaption: { ...TYPE.caption, color: COLORS.faint, marginTop: SPACING.sm, lineHeight: 17 },
  secondaryBtn: {
    backgroundColor: COLORS.primaryLight, borderRadius: RADIUS.md, padding: SPACING.md,
    alignItems: 'center', marginTop: SPACING.md,
  },
  secondaryBtnText: { color: COLORS.primaryDark, fontWeight: '700' },
  modeRow: { flexDirection: 'row', gap: SPACING.sm, flexWrap: 'wrap' },
  modeChip: { borderWidth: 1, borderColor: COLORS.border, borderRadius: RADIUS.pill, paddingVertical: 8, paddingHorizontal: SPACING.md },
  modeChipActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  modeChipText: { fontSize: 12, color: COLORS.text },
  modeChipTextActive: { color: 'white', fontWeight: '700' },
});
