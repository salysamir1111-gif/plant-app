import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Switch } from 'react-native';
import { COLORS, NOTIFICATION_MODES } from '../utils/constants';

export default function SettingsScreen() {
  const [globalMode, setGlobalMode] = useState(NOTIFICATION_MODES.FULL);
  const [units, setUnits] = useState('metric');

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Settings</Text>

      <Section title="Notifications (global default)">
        <Text style={styles.helper}>
          Individual plants can override this in their own detail screen.
        </Text>
        {[
          { key: NOTIFICATION_MODES.FULL, label: 'Full reminders', desc: 'Watering, disease alerts, weekly digest' },
          { key: NOTIFICATION_MODES.DIGEST, label: 'Gentle weekly digest', desc: 'One combined summary per week' },
          { key: NOTIFICATION_MODES.OFF, label: 'On-demand only', desc: 'No pushes — check in whenever you like' },
        ].map((opt) => (
          <TouchableOpacity key={opt.key} style={styles.option} onPress={() => setGlobalMode(opt.key)}>
            <View style={[styles.radio, globalMode === opt.key && styles.radioActive]} />
            <View style={{ flex: 1 }}>
              <Text style={styles.optionLabel}>{opt.label}</Text>
              <Text style={styles.optionDesc}>{opt.desc}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </Section>

      <Section title="Units">
        <View style={styles.row}>
          <Text style={styles.optionLabel}>Use imperial units</Text>
          <Switch
            value={units === 'imperial'}
            onValueChange={(v) => setUnits(v ? 'imperial' : 'metric')}
            trackColor={{ true: COLORS.primary }}
          />
        </View>
      </Section>

      <Section title="Location">
        <Text style={styles.helper}>
          Used for climate zone, frost alerts, and rainfall advice. Update anytime from Onboarding.
        </Text>
      </Section>
    </View>
  );
}

function Section({ title, children }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background, padding: 16 },
  title: { fontSize: 26, fontWeight: '800', color: COLORS.text, marginBottom: 8 },
  section: { marginTop: 20 },
  sectionTitle: { fontSize: 15, fontWeight: '700', color: COLORS.text, marginBottom: 8 },
  helper: { fontSize: 12, color: COLORS.subtext, marginBottom: 10 },
  option: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, gap: 10 },
  radio: { width: 18, height: 18, borderRadius: 9, borderWidth: 2, borderColor: COLORS.border },
  radioActive: { borderColor: COLORS.primary, backgroundColor: COLORS.primary },
  optionLabel: { fontSize: 14, fontWeight: '600', color: COLORS.text },
  optionDesc: { fontSize: 12, color: COLORS.subtext },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
});
