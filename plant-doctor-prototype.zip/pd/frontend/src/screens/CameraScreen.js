import React, { useRef, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { COLORS, RADIUS, SPACING } from '../utils/constants';
import { api } from '../services/api';

export default function CameraScreen({ route, navigation }) {
  const { mode = 'identify', plantId } = route.params || {};
  const [permission, requestPermission] = useCameraPermissions();
  const cameraRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  if (!permission) return <View style={styles.container} />;

  if (!permission.granted) {
    return (
      <View style={styles.center}>
        <Text style={styles.permText}>Camera access is needed to identify or check on a plant.</Text>
        <TouchableOpacity style={styles.primaryBtn} onPress={requestPermission}>
          <Text style={styles.primaryBtnText}>Grant permission</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const takePhoto = async () => {
    if (!cameraRef.current || busy) return;
    setBusy(true);
    setError(null);
    try {
      const photo = await cameraRef.current.takePictureAsync({ base64: true, quality: 0.6 });

      if (mode === 'healthcheck') {
        const result = await api.checkPlantHealth(plantId, photo.base64);
        navigation.replace('HealthCheckResult', { photoUri: photo.uri, result, plantId });
      } else {
        const result = await api.identifyPlant(photo.base64);
        navigation.replace('IdentifyResult', { photoUri: photo.uri, result });
      }
    } catch (e) {
      // Be specific about what failed instead of a generic alert — the most
      // common cause during setup is the backend not being reachable yet.
      setError(`Couldn't reach the identification service: ${e.message}. Check that the backend is running and that api.js points at it.`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={styles.container}>
      <CameraView ref={cameraRef} style={styles.camera} facing="back" />
      <View style={styles.controls}>
        {error ? <Text style={styles.error}>{error}</Text> : null}
        <TouchableOpacity style={styles.shutter} onPress={takePhoto} disabled={busy}>
          {busy ? <ActivityIndicator color="white" /> : <View style={styles.shutterInner} />}
        </TouchableOpacity>
        <Text style={styles.hint}>
          {mode === 'healthcheck'
            ? 'Frame the leaves showing signs of trouble, in good light'
            : 'Frame the whole plant — sharp, well-lit photos match better'}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'black' },
  camera: { flex: 1 },
  controls: { position: 'absolute', bottom: 40, left: 0, right: 0, alignItems: 'center', paddingHorizontal: SPACING.xl },
  shutter: {
    width: 72, height: 72, borderRadius: 36, backgroundColor: COLORS.primary,
    alignItems: 'center', justifyContent: 'center', borderWidth: 4, borderColor: 'white',
  },
  shutterInner: { width: 50, height: 50, borderRadius: 25, backgroundColor: 'white' },
  hint: { color: 'white', marginTop: 12, fontSize: 12, opacity: 0.85, textAlign: 'center' },
  error: {
    color: 'white', backgroundColor: COLORS.danger, fontSize: 12.5, textAlign: 'center',
    marginBottom: 14, padding: 10, borderRadius: RADIUS.sm, overflow: 'hidden',
  },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: COLORS.background },
  permText: { textAlign: 'center', color: COLORS.text, marginBottom: 16 },
  primaryBtn: { backgroundColor: COLORS.primary, paddingVertical: 12, paddingHorizontal: 24, borderRadius: RADIUS.pill },
  primaryBtnText: { color: 'white', fontWeight: '700' },
});
