import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { COLORS, RADIUS, SHADOW, SPACING, TYPE } from '../utils/constants';
import { usePlants } from '../context/PlantContext';
import { api } from '../services/api';

export default function WateringScheduleScreen() {
  const { plants, location } = usePlants();
  const [schedules, setSchedules] = useState({});
  const [failed, setFailed] = useState({});

  useEffect(() => {
    plants.forEach((p) => {
      api
        .getWateringSchedule(p.species, location?.lat, location?.lon)
        .then((s) => setSchedules((prev) => ({ ...prev, [p.id]: s })))
        .catch(() => setFailed((prev) => ({ ...prev, [p.id]: true })));
    });
  }, [plants]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Watering Schedule</Text>
      <Text style={styles.subtitle}>Estimates based on species and local weather — not exact.</Text>
      <FlatList
        data={plants}
        keyExtractor={(p) => p.id}
        contentContainerStyle={{ padding: SPACING.lg }}
        renderItem={({ item }) => (
          <View style={styles.row}>
            <Text style={styles.plantName}>{item.name}</Text>
            <Text style={failed[item.id] ? styles.freqUnavailable : styles.freq}>
              {failed[item.id]
                ? 'Unavailable'
                : schedules[item.id]
                ? `Every ${schedules[item.id].frequencyDays} day(s)`
                : 'Loading…'}
            </Text>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>No plants tracked yet.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  title: { ...TYPE.display, color: COLORS.text, paddingHorizontal: SPACING.lg, paddingTop: SPACING.md },
  subtitle: { ...TYPE.caption, color: COLORS.subtext, paddingHorizontal: SPACING.lg, marginTop: 4 },
  row: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: COLORS.card, borderRadius: RADIUS.md, padding: SPACING.md, marginBottom: SPACING.sm,
    ...SHADOW.card,
  },
  plantName: { fontSize: 15, fontWeight: '700', color: COLORS.text },
  freq: { fontSize: 13, color: COLORS.primary, fontWeight: '700' },
  freqUnavailable: { fontSize: 13, color: COLORS.faint, fontWeight: '600' },
  empty: { textAlign: 'center', color: COLORS.subtext, marginTop: 40 },
});
