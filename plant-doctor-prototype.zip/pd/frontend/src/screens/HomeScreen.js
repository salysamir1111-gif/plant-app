import React, { useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { COLORS, RADIUS, SHADOW, SPACING, TYPE } from '../utils/constants';
import { usePlants } from '../context/PlantContext';
import PlantCard from '../components/PlantCard';

export default function HomeScreen({ navigation }) {
  const { plants, refreshPlants, usingSampleData } = usePlants();

  useEffect(() => {
    refreshPlants();
  }, [refreshPlants]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>My Plants</Text>
          <Text style={styles.subtitle}>{plants.length} tracked</Text>
        </View>
        <TouchableOpacity style={styles.addBtn} onPress={() => navigation.navigate('Camera')}>
          <Text style={styles.addBtnText}>+ Scan</Text>
        </TouchableOpacity>
      </View>

      {usingSampleData && (
        <View style={styles.sampleBanner}>
          <Text style={styles.sampleBannerText}>
            Showing sample plants — the app couldn't reach the backend, so this isn't your real, saved data.
          </Text>
        </View>
      )}

      <FlatList
        data={plants}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: SPACING.lg, paddingTop: SPACING.sm }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyEmoji}>🌱</Text>
            <Text style={styles.emptyText}>No plants yet — tap "+ Scan" to identify your first one.</Text>
          </View>
        }
        renderItem={({ item }) => (
          <PlantCard plant={item} onPress={() => navigation.navigate('PlantDetail', { plantId: item.id })} />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: SPACING.lg, paddingTop: SPACING.md,
  },
  title: { ...TYPE.display, color: COLORS.text },
  subtitle: { ...TYPE.caption, color: COLORS.subtext, marginTop: 2 },
  addBtn: {
    backgroundColor: COLORS.primary, borderRadius: RADIUS.pill,
    paddingVertical: 10, paddingHorizontal: SPACING.lg, ...SHADOW.card,
  },
  addBtnText: { color: 'white', fontWeight: '800', fontSize: 13.5 },
  sampleBanner: {
    marginHorizontal: SPACING.lg, marginTop: SPACING.md,
    backgroundColor: COLORS.warningLight, borderWidth: 1, borderColor: COLORS.warning,
    borderRadius: RADIUS.md, padding: SPACING.md,
  },
  sampleBannerText: { color: COLORS.warning, fontSize: 12.5, fontWeight: '600', lineHeight: 18 },
  empty: { alignItems: 'center', marginTop: 80, paddingHorizontal: SPACING.xl },
  emptyEmoji: { fontSize: 40, marginBottom: SPACING.sm },
  emptyText: { textAlign: 'center', color: COLORS.subtext, fontSize: 14, lineHeight: 20 },
});
