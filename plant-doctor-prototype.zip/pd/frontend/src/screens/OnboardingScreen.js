import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import * as Location from 'expo-location';
import { COLORS } from '../utils/constants';
import { usePlants } from '../context/PlantContext';

export default function OnboardingScreen({ navigation }) {
  const { setLocation } = usePlants();
  const [status, setStatus] = useState('idle');

  const useGPS = async () => {
    setStatus('requesting');
    const { status: permStatus } = await Location.requestForegroundPermissionsAsync();
    if (permStatus !== 'granted') {
      setStatus('denied');
      return;
    }
    const pos = await Location.getCurrentPositionAsync({});
    setLocation({ lat: pos.coords.latitude, lon: pos.coords.longitude });
    navigation.replace('Main');
  };

  const skip = () => navigation.replace('Main');

  return (
    <View style={styles.container}>
      <Text style={styles.emoji}>🌱</Text>
      <Text style={styles.title}>Welcome to Plant Care</Text>
      <Text style={styles.subtitle}>
        Share your location so we can auto-detect your climate zone, frost
        dates, and rainfall patterns. You can skip this and set it manually later.
      </Text>

      <TouchableOpacity style={styles.primaryBtn} onPress={useGPS}>
        <Text style={styles.primaryBtnText}>Use my location</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.secondaryBtn} onPress={skip}>
        <Text style={styles.secondaryBtnText}>Skip for now</Text>
      </TouchableOpacity>

      {status === 'denied' && (
        <Text style={styles.error}>Location permission denied — you can enable it later in Settings.</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background, alignItems: 'center', justifyContent: 'center', padding: 24 },
  emoji: { fontSize: 56, marginBottom: 16 },
  title: { fontSize: 24, fontWeight: '800', color: COLORS.text, marginBottom: 8 },
  subtitle: { fontSize: 14, color: COLORS.subtext, textAlign: 'center', marginBottom: 32, lineHeight: 20 },
  primaryBtn: { backgroundColor: COLORS.primary, paddingVertical: 14, paddingHorizontal: 32, borderRadius: 30, marginBottom: 12, width: '100%', alignItems: 'center' },
  primaryBtnText: { color: 'white', fontWeight: '700', fontSize: 16 },
  secondaryBtn: { paddingVertical: 10 },
  secondaryBtnText: { color: COLORS.subtext, fontSize: 14 },
  error: { color: COLORS.danger, marginTop: 16, textAlign: 'center', fontSize: 13 },
});
