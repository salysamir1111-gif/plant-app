import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TextInput, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
import { COLORS, RADIUS, SHADOW, SPACING, TYPE, identificationCaption } from '../utils/constants';
import { usePlants } from '../context/PlantContext';
import ConfidenceNote from '../components/ConfidenceNote';

export default function IdentifyResultScreen({ route, navigation }) {
  const { photoUri, result } = route.params || {};
  const { addPlant } = usePlants();
  const [name, setName] = useState(result?.commonName || '');
  const [species, setSpecies] = useState(result?.species || '');
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);

  const confidence = result?.confidence ?? 0;
  const isDemo = !!result?.isDemo;
  const lowConfidence = !isDemo && confidence < 0.6;

  const save = async () => {
    setSaving(true);
    try {
      const created = await addPlant({
        name: name.trim() || 'Unnamed plant',
        species: species.trim() || 'Unknown species',
        photoUrl: photoUri,
        healthScore: 100,
        identifyConfidence: isDemo ? null : confidence,
        identifyIsDemo: isDemo,
      });
      navigation.replace('PlantDetail', { plantId: created.id });
    } catch (e) {
      alert(`Couldn't save this plant: ${e.message}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: SPACING.lg }}>
      {photoUri ? (
        <Image source={{ uri: photoUri }} style={styles.photo} />
      ) : (
        <View style={[styles.photo, styles.photoPlaceholder]}>
          <Text style={{ fontSize: 40 }}>🌿</Text>
        </View>
      )}

      <Text style={styles.eyebrow}>WHAT WE THINK THIS IS</Text>

      {editing ? (
        <View style={styles.editBlock}>
          <TextInput
            style={styles.input}
            value={name}
            onChangeText={setName}
            placeholder="What do you call this plant?"
            placeholderTextColor={COLORS.faint}
          />
          <TextInput
            style={styles.input}
            value={species}
            onChangeText={setSpecies}
            placeholder="Species (optional)"
            placeholderTextColor={COLORS.faint}
          />
        </View>
      ) : (
        <View style={styles.resultBlock}>
          <Text style={styles.name}>{name || 'Unnamed plant'}</Text>
          {species ? <Text style={styles.species}>{species}</Text> : null}
        </View>
      )}

      <ConfidenceNote
        confidence={confidence}
        isDemo={isDemo}
        caption={identificationCaption({ isDemo, confidence })}
      />

      {(lowConfidence || isDemo) && (
        <Text style={styles.warnText}>
          {isDemo
            ? 'Connect a Plant.id API key on the backend to get real matches. Until then, every scan will show this same placeholder.'
            : "We're not confident in this match. Take another photo in better light, or rename it yourself below."}
        </Text>
      )}

      <TouchableOpacity style={styles.editToggle} onPress={() => setEditing((v) => !v)}>
        <Text style={styles.editToggleText}>
          {editing ? '✓ Done editing' : "✎ This isn't right — let me fix it"}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.retakeBtn} onPress={() => navigation.goBack()}>
        <Text style={styles.retakeBtnText}>↺ Retake photo</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.saveBtn} onPress={save} disabled={saving}>
        {saving ? <ActivityIndicator color="white" /> : <Text style={styles.saveBtnText}>Add to my plants</Text>}
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  photo: { width: '100%', height: 220, borderRadius: RADIUS.lg, marginBottom: SPACING.lg },
  photoPlaceholder: { backgroundColor: COLORS.primaryLight, alignItems: 'center', justifyContent: 'center' },
  eyebrow: { ...TYPE.label, color: COLORS.subtext, marginBottom: SPACING.sm },
  resultBlock: { marginBottom: SPACING.md },
  name: { ...TYPE.display, fontSize: 24, color: COLORS.text },
  species: { fontSize: 14, color: COLORS.subtext, fontStyle: 'italic', marginTop: 2 },
  editBlock: { marginBottom: SPACING.md, gap: SPACING.sm },
  input: {
    borderWidth: 1, borderColor: COLORS.border, borderRadius: RADIUS.sm,
    paddingVertical: 10, paddingHorizontal: SPACING.md, fontSize: 15, color: COLORS.text,
    backgroundColor: COLORS.card,
  },
  warnText: { ...TYPE.caption, color: COLORS.subtext, marginTop: SPACING.md, lineHeight: 18 },
  editToggle: { marginTop: SPACING.lg, alignSelf: 'flex-start' },
  editToggleText: { color: COLORS.primary, fontWeight: '700', fontSize: 13.5 },
  retakeBtn: { marginTop: SPACING.md, alignItems: 'center', paddingVertical: 10 },
  retakeBtnText: { color: COLORS.subtext, fontWeight: '600', fontSize: 13.5 },
  saveBtn: {
    backgroundColor: COLORS.primary, borderRadius: RADIUS.pill, paddingVertical: 15,
    alignItems: 'center', marginTop: SPACING.lg, ...SHADOW.floating,
  },
  saveBtnText: { color: 'white', fontWeight: '800', fontSize: 15.5 },
});
