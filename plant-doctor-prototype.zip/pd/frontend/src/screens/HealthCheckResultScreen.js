import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { COLORS, RADIUS, SHADOW, SPACING, TYPE, confidenceLabelFor } from '../utils/constants';
import { usePlants } from '../context/PlantContext';
import ConfidenceNote from '../components/ConfidenceNote';

export default function HealthCheckResultScreen({ route, navigation }) {
  const { photoUri, result, plantId } = route.params || {};
  const { updatePlantHealth } = usePlants();
  const [saving, setSaving] = useState(false);

  const isDemo = !!result?.isDemo;
  const findings = result?.findings || [];

  const save = async () => {
    setSaving(true);
    try {
      await updatePlantHealth(plantId, result.healthScore, isDemo);
      navigation.replace('PlantDetail', { plantId });
    } catch (e) {
      alert(`Couldn't save this check-up: ${e.message}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: SPACING.lg }}>
      {photoUri ? <Image source={{ uri: photoUri }} style={styles.photo} /> : null}

      {isDemo && (
        <View style={styles.demoBanner}>
          <Text style={styles.demoBannerText}>
            No disease-detection API key is configured on the backend — this isn't a real diagnosis. Add PLANT_ID_API_KEY to get one.
          </Text>
        </View>
      )}

      <Text style={styles.eyebrow}>CHECK-UP RESULT</Text>
      <Text style={styles.summary}>{result?.summary || 'No summary returned.'}</Text>

      {findings.length === 0 ? (
        <View style={styles.okBox}>
          <Text style={styles.okText}>
            {isDemo ? 'No findings — because no real check ran.' : 'No issues found in this photo.'}
          </Text>
        </View>
      ) : (
        findings.map((f, i) => {
          const c = confidenceLabelFor(f.confidence);
          return (
            <View key={i} style={styles.findingCard}>
              <Text style={styles.findingTitle}>{f.issue}</Text>
              <ConfidenceNote confidence={f.confidence} caption={`${c.pct}% confidence this is what's affecting your plant.`} />
              <Text style={styles.stepsHeader}>Suggested next steps</Text>
              {f.treatmentSteps.map((step, j) => (
                <Text key={j} style={styles.step}>• {step}</Text>
              ))}
            </View>
          );
        })
      )}

      <Text style={styles.disclaimer}>
        This is an automated read of a single photo, not a lab diagnosis. If a plant is in serious decline, it's worth checking with a local nursery or extension office too.
      </Text>

      <TouchableOpacity style={styles.saveBtn} onPress={save} disabled={saving}>
        {saving ? <ActivityIndicator color="white" /> : <Text style={styles.saveBtnText}>Save to this plant</Text>}
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  photo: { width: '100%', height: 200, borderRadius: RADIUS.lg, marginBottom: SPACING.lg },
  demoBanner: {
    backgroundColor: COLORS.warningLight, borderWidth: 1, borderColor: COLORS.warning,
    borderRadius: RADIUS.md, padding: SPACING.md, marginBottom: SPACING.lg,
  },
  demoBannerText: { color: COLORS.warning, fontSize: 12.5, fontWeight: '600', lineHeight: 18 },
  eyebrow: { ...TYPE.label, color: COLORS.subtext, marginBottom: SPACING.xs },
  summary: { ...TYPE.title, color: COLORS.text, marginBottom: SPACING.lg },
  okBox: {
    backgroundColor: COLORS.primaryLight, borderRadius: RADIUS.md, padding: SPACING.lg,
    alignItems: 'center', marginBottom: SPACING.lg,
  },
  okText: { color: COLORS.primaryDark, fontWeight: '600', fontSize: 14 },
  findingCard: {
    backgroundColor: COLORS.card, borderRadius: RADIUS.md, borderWidth: 1, borderColor: COLORS.border,
    padding: SPACING.lg, marginBottom: SPACING.md, gap: SPACING.sm, ...SHADOW.card,
  },
  findingTitle: { ...TYPE.subtitle, color: COLORS.text },
  stepsHeader: { ...TYPE.caption, color: COLORS.subtext, fontWeight: '700', marginTop: SPACING.xs },
  step: { fontSize: 13.5, color: COLORS.text, lineHeight: 19 },
  disclaimer: { ...TYPE.caption, color: COLORS.subtext, lineHeight: 18, marginTop: SPACING.sm, marginBottom: SPACING.lg },
  saveBtn: {
    backgroundColor: COLORS.primary, borderRadius: RADIUS.pill, paddingVertical: 15,
    alignItems: 'center', ...SHADOW.floating,
  },
  saveBtnText: { color: 'white', fontWeight: '800', fontSize: 15.5 },
});
