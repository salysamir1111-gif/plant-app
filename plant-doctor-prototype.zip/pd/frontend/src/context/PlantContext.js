import React, { createContext, useContext, useState, useCallback } from 'react';
import { api } from '../services/api';
import { NOTIFICATION_MODES } from '../utils/constants';

const PlantContext = createContext(null);

export function PlantProvider({ children }) {
  const [plants, setPlants] = useState([]);
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState(null); // { lat, lon, region }
  const [usingSampleData, setUsingSampleData] = useState(false);

  const refreshPlants = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.listPlants();
      setPlants(data);
      setUsingSampleData(false);
    } catch (e) {
      // Backend isn't reachable — show clearly-labeled sample plants rather
      // than a blank screen, but never let the UI imply these are real,
      // saved data.
      setUsingSampleData(true);
      setPlants((prev) => (prev.length ? prev : DEMO_PLANTS));
    } finally {
      setLoading(false);
    }
  }, []);

  const addPlant = useCallback(async (plant) => {
    const created = await api.createPlant(plant);
    setPlants((prev) => [...prev, created]);
    setUsingSampleData(false);
    return created;
  }, []);

  const setPlantNotificationMode = useCallback(async (plantId, mode) => {
    setPlants((prev) => prev.map((p) => (p.id === plantId ? { ...p, notificationMode: mode } : p)));
    await api.updatePlant(plantId, { notificationMode: mode });
  }, []);

  // Records the result of a real check-up. isDemo means no real detection
  // ran, so we still save the number (so the UI has something to show) but
  // keep it flagged as an estimate rather than a confirmed reading.
  const updatePlantHealth = useCallback(async (plantId, healthScore, isDemo) => {
    setPlants((prev) => prev.map((p) => (p.id === plantId ? { ...p, healthScore, healthScoreIsEstimate: true } : p)));
    await api.updatePlant(plantId, { healthScore, healthScoreIsEstimate: true });
  }, []);

  return (
    <PlantContext.Provider
      value={{
        plants,
        loading,
        location,
        usingSampleData,
        setLocation,
        refreshPlants,
        addPlant,
        setPlantNotificationMode,
        updatePlantHealth,
      }}
    >
      {children}
    </PlantContext.Provider>
  );
}

export function usePlants() {
  const ctx = useContext(PlantContext);
  if (!ctx) throw new Error('usePlants must be used within a PlantProvider');
  return ctx;
}

// Shown only when the backend can't be reached, so the UI isn't empty.
// These are never passed through addPlant/api, so they can't be mistaken
// for something the user actually saved.
const DEMO_PLANTS = [
  { id: 'demo-1', name: 'Monstera', species: 'Monstera deliciosa', healthScore: 88, notificationMode: NOTIFICATION_MODES.FULL, healthScoreIsEstimate: true },
  { id: 'demo-2', name: 'Basil', species: 'Ocimum basilicum', healthScore: 62, notificationMode: NOTIFICATION_MODES.DIGEST, healthScoreIsEstimate: true },
];
