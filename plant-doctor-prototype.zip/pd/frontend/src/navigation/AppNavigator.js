import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import OnboardingScreen from '../screens/OnboardingScreen';
import HomeScreen from '../screens/HomeScreen';
import CameraScreen from '../screens/CameraScreen';
import IdentifyResultScreen from '../screens/IdentifyResultScreen';
import HealthCheckResultScreen from '../screens/HealthCheckResultScreen';
import PlantDetailScreen from '../screens/PlantDetailScreen';
import WateringScheduleScreen from '../screens/WateringScheduleScreen';
import SettingsScreen from '../screens/SettingsScreen';
import { COLORS } from '../utils/constants';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: COLORS.primary,
      }}
    >
      <Tab.Screen name="Plants" component={HomeScreen} />
      <Tab.Screen name="Watering" component={WateringScheduleScreen} />
      <Tab.Screen name="Settings" component={SettingsScreen} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <Stack.Navigator initialRouteName="Onboarding" screenOptions={{ headerShown: true }}>
      <Stack.Screen name="Onboarding" component={OnboardingScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Main" component={MainTabs} options={{ headerShown: false }} />
      <Stack.Screen name="Camera" component={CameraScreen} options={{ title: 'Scan a Plant' }} />
      <Stack.Screen name="IdentifyResult" component={IdentifyResultScreen} options={{ title: 'Confirm Match' }} />
      <Stack.Screen name="HealthCheckResult" component={HealthCheckResultScreen} options={{ title: 'Check-up Result' }} />
      <Stack.Screen name="PlantDetail" component={PlantDetailScreen} options={{ title: 'Plant Details' }} />
    </Stack.Navigator>
  );
}
