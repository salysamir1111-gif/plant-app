// TODO: replace with your Firebase project config (Project settings > General)
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: 'YOUR_API_KEY',
  authDomain: 'YOUR_PROJECT.firebaseapp.com',
  projectId: 'YOUR_PROJECT',
  storageBucket: 'YOUR_PROJECT.appspot.com',
  messagingSenderId: 'YOUR_SENDER_ID',
  appId: 'YOUR_APP_ID',
};

export const firebaseApp = initializeApp(firebaseConfig);
export const db = getFirestore(firebaseApp);
export const auth = getAuth(firebaseApp);

// Firestore shape (suggested):
// users/{uid}
// users/{uid}/plants/{plantId} = {
//   name, species, photoUrl, healthScore, wateringMode,
//   notificationMode: 'full' | 'digest' | 'off',
//   createdAt, lastWateredAt, lastScanAt
// }
// users/{uid}/plants/{plantId}/scans/{scanId} = { photoUrl, healthScore, notes, createdAt }
