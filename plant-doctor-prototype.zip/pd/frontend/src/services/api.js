// Central place to point the app at your FastAPI backend.
// Use your machine's LAN IP (e.g. http://192.168.1.20:8000) when testing on
// a physical device — "localhost" only works in a simulator/web preview.
const BASE_URL = 'http://localhost:8000';

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`API ${path} failed (${res.status}): ${text}`);
  }
  return res.json();
}

export const api = {
  // Send a photo (base64) for species identification
  identifyPlant: (imageBase64) =>
    request('/identify', {
      method: 'POST',
      body: JSON.stringify({ image_base64: imageBase64 }),
    }),

  // Send current + previous photo for a health-check diff
  checkPlantHealth: (plantId, imageBase64) =>
    request('/disease/check', {
      method: 'POST',
      body: JSON.stringify({ plant_id: plantId, image_base64: imageBase64 }),
    }),

  // Get an adaptive watering schedule for a species/location
  getWateringSchedule: (species, lat, lon) =>
    request(`/watering/schedule?species=${encodeURIComponent(species)}&lat=${lat}&lon=${lon}`),

  // Get local climate / frost date info
  getClimateInfo: (lat, lon) =>
    request(`/weather/climate?lat=${lat}&lon=${lon}`),

  // Plant CRUD (backed by Firestore in production; stubbed here)
  listPlants: () => request('/plants'),
  createPlant: (plant) => request('/plants', { method: 'POST', body: JSON.stringify(plant) }),
  updatePlant: (id, patch) => request(`/plants/${id}`, { method: 'PATCH', body: JSON.stringify(patch) }),
};
