# Firebase setup

1. Create a project at https://console.firebase.google.com
2. Enable **Authentication** (Email/Google/Apple sign-in as needed).
3. Enable **Firestore** in production mode, then deploy `firestore.rules`:
   ```bash
   npm install -g firebase-tools
   firebase login
   firebase init firestore   # point it at this rules file
   firebase deploy --only firestore:rules
   ```
4. Enable **Cloud Messaging** for push notifications, and add your server key
   to the backend if you want to trigger pushes from FastAPI (e.g. weekly
   digest, frost alerts) rather than only from client-side listeners.
5. Copy your web app config into `frontend/src/services/firebase.js`.

## Data model
```
users/{uid}
users/{uid}/plants/{plantId}
  - name, species, photoUrl, healthScore
  - notificationMode: "full" | "digest" | "off"
  - createdAt, lastWateredAt, lastScanAt
users/{uid}/plants/{plantId}/scans/{scanId}
  - photoUrl, healthScore, notes, createdAt
```
