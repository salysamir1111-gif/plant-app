# Plant Doctor Backend — Simple Version

The backend is intentionally kept in **one file: `main.py`**.

That makes it easier to teach, explain, and modify.

## Start it

```bash
cd backend
pip install -r requirements.txt
copy .env.example .env
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

## API flow

- `POST /identify` → identify a plant from a photo.
- `POST /disease/check` → visual health check.
- `GET /plants` → list saved development plants.
- `POST /plants` → create a plant.
- `PATCH /plants/{id}` → update a plant.
- `GET /watering/schedule` → estimate watering frequency.
- `GET /weather/climate` → climate information.

The in-memory `PLANTS` dictionary is for development only. It resets when the server restarts. Replace it with Firebase/Firestore when accounts and cloud sync are added.
