"""Plant Doctor backend.

This file intentionally keeps the backend simple: all API routes, small models,
and development helpers live here so a beginner can understand the whole server
without jumping between many folders.

Run:
    pip install -r requirements.txt
    uvicorn main:app --reload --host 0.0.0.0 --port 8000
"""

import base64
import os
import uuid
from typing import Optional

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# -----------------------------------------------------------------------------
# 1. SETTINGS
# -----------------------------------------------------------------------------

load_dotenv()

PLANT_ID_API_KEY = os.getenv("PLANT_ID_API_KEY", "")
PLANT_ID_URL = os.getenv("PLANT_ID_BASE_URL", "https://api.plant.id/v3")
WEATHER_API_KEY = os.getenv("WEATHER_API_KEY", "")
WEATHER_URL = os.getenv(
    "WEATHER_BASE_URL", "https://api.openweathermap.org/data/2.5"
)

# -----------------------------------------------------------------------------
# 2. APP
# -----------------------------------------------------------------------------

app = FastAPI(title="Plant Doctor API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Fine for local development. Restrict in production.
    allow_methods=["*"],
    allow_headers=["*"],
)

# Temporary database for development.
# Replace this dictionary with Firestore when user accounts are added.
PLANTS: dict[str, dict] = {}

# -----------------------------------------------------------------------------
# 3. DATA MODELS
# -----------------------------------------------------------------------------


class IdentifyRequest(BaseModel):
    image_base64: str


class DiseaseRequest(BaseModel):
    plant_id: str
    image_base64: str


class PlantCreate(BaseModel):
    name: str
    species: str
    photoUrl: Optional[str] = None
    healthScore: int = 100
    notificationMode: str = "full"
    identifyConfidence: Optional[float] = None
    identifyIsDemo: bool = False
    healthScoreIsEstimate: bool = True
    lastWateredAt: Optional[str] = None
    nextWateringAt: Optional[str] = None
    lastCheckedAt: Optional[str] = None


class PlantUpdate(BaseModel):
    name: Optional[str] = None
    species: Optional[str] = None
    healthScore: Optional[int] = None
    notificationMode: Optional[str] = None
    healthScoreIsEstimate: Optional[bool] = None
    lastWateredAt: Optional[str] = None
    nextWateringAt: Optional[str] = None
    lastCheckedAt: Optional[str] = None


# -----------------------------------------------------------------------------
# 4. PLANT AI
# -----------------------------------------------------------------------------

async def identify_plant(image_base64: str) -> dict:
    """Identify a plant with Plant.id, or return clearly marked demo data."""
    if not PLANT_ID_API_KEY:
        return {
            "species": "Monstera deliciosa",
            "commonName": "Swiss Cheese Plant",
            "confidence": 0.0,
            "careTips": None,
            "isDemo": True,
        }

    # Basic validation before sending the image to the external service.
    try:
        base64.b64decode(image_base64, validate=True)
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Invalid image data.") from exc

    response = await _plant_id_request(
        "/identification",
        {
            "images": [f"data:image/jpeg;base64,{image_base64}"],
            "similar_images": True,
        },
    )

    suggestions = (
        response.get("result", {})
        .get("classification", {})
        .get("suggestions", [])
    )
    suggestion = suggestions[0] if suggestions else {}
    details = suggestion.get("details", {}) or {}
    common_names = details.get("common_names", []) or []

    return {
        "species": suggestion.get("name", "Unknown"),
        "commonName": common_names[0] if common_names else suggestion.get("name", "Unknown"),
        "confidence": suggestion.get("probability", 0.0),
        "careTips": None,
        "isDemo": False,
    }


async def check_disease(image_base64: str) -> dict:
    """Run visual health analysis. This is not a laboratory diagnosis."""
    if not PLANT_ID_API_KEY:
        return {
            "healthScore": 85,
            "findings": [],
            "summary": "No API key configured, so no real health check ran.",
            "isDemo": True,
        }

    response = await _plant_id_request(
        "/identification",
        {
            "images": [f"data:image/jpeg;base64,{image_base64}"],
            "health": "all",
        },
    )

    result = response.get("result", {})
    healthy = result.get("is_healthy", {}).get("binary", True)
    diseases = result.get("disease", {}).get("suggestions", []) or []

    findings = []
    for disease in diseases[:3]:
        findings.append(
            {
                "issue": disease.get("name", "Unknown issue"),
                "confidence": disease.get("probability", 0.0),
                "treatmentSteps": [
                    "Isolate the plant if pests or disease are suspected.",
                    "Remove badly affected leaves with clean scissors.",
                    "Adjust watering and light, then check again in 5–7 days.",
                ],
            }
        )

    return {
        "healthScore": 90 if healthy else 55,
        "findings": findings,
        "summary": (
            "No visual issues detected in this photo."
            if healthy
            else "Possible visual issues found — see the suggested next steps."
        ),
        "isDemo": False,
    }


async def _plant_id_request(path: str, payload: dict) -> dict:
    headers = {
        "Api-Key": PLANT_ID_API_KEY,
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            f"{PLANT_ID_URL}{path}",
            headers=headers,
            json=payload,
        )
        response.raise_for_status()
        return response.json()


# -----------------------------------------------------------------------------
# 5. WEATHER
# -----------------------------------------------------------------------------

async def get_weather(lat: float, lon: float) -> dict:
    """Get weather data or simple demo values when no API key exists."""
    if not WEATHER_API_KEY:
        return {
            "tempC": 22.0,
            "humidity": 55,
            "rainLast24hMm": 0.0,
            "demo": True,
        }

    async with httpx.AsyncClient(timeout=15) as client:
        response = await client.get(
            f"{WEATHER_URL}/weather",
            params={
                "lat": lat,
                "lon": lon,
                "appid": WEATHER_API_KEY,
                "units": "metric",
            },
        )
        response.raise_for_status()
        data = response.json()

    return {
        "tempC": data.get("main", {}).get("temp"),
        "humidity": data.get("main", {}).get("humidity"),
        "rainLast24hMm": data.get("rain", {}).get("1h", 0.0),
        "demo": False,
    }


# -----------------------------------------------------------------------------
# 6. API ROUTES — these are the functions Flutter calls
# -----------------------------------------------------------------------------

@app.get("/")
async def root():
    return {"status": "ok", "service": "plant-doctor-api"}


@app.post("/identify")
async def identify(request: IdentifyRequest):
    return await identify_plant(request.image_base64)


@app.post("/disease/check")
async def disease_check(request: DiseaseRequest):
    return await check_disease(request.image_base64)


@app.get("/plants")
async def list_plants():
    return list(PLANTS.values())


@app.post("/plants")
async def create_plant(plant: PlantCreate):
    plant_id = str(uuid.uuid4())
    saved = {"id": plant_id, **plant.model_dump()}
    PLANTS[plant_id] = saved
    return saved


@app.patch("/plants/{plant_id}")
async def update_plant(plant_id: str, update: PlantUpdate):
    if plant_id not in PLANTS:
        raise HTTPException(status_code=404, detail="Plant not found")

    changes = {
        key: value
        for key, value in update.model_dump().items()
        if value is not None
    }
    PLANTS[plant_id].update(changes)
    return PLANTS[plant_id]


# Starting point for the watering database.
WATERING_DAYS = {
    "monstera deliciosa": 7,
    "ocimum basilicum": 3,
    "succulent": 14,
    "cactus": 21,
}


@app.get("/watering/schedule")
async def watering_schedule(
    species: str,
    lat: Optional[float] = Query(default=None),
    lon: Optional[float] = Query(default=None),
):
    days = WATERING_DAYS.get(species.lower(), 7)
    note = "This is an estimate, not a soil-moisture reading."

    if lat is not None and lon is not None:
        weather = await get_weather(lat, lon)
        humidity = weather.get("humidity")

        if humidity is not None and humidity > 70:
            days += 2
            note = "Estimated watering interval extended because local humidity is high."
        elif humidity is not None and humidity < 30:
            days = max(1, days - 2)
            note = "Estimated watering interval shortened because local humidity is low."

    return {
        "frequencyDays": days,
        "note": note,
        "isEstimate": True,
    }


@app.get("/weather/climate")
async def climate(
    lat: Optional[float] = Query(default=None),
    lon: Optional[float] = Query(default=None),
):
    if lat is None or lon is None:
        return {
            "zone": None,
            "avgLastFrostDate": None,
            "avgFirstFrostDate": None,
            "recentRainfallMm": None,
            "note": "No location set. Enable GPS for climate-aware advice.",
            "isEstimate": True,
        }

    latitude = abs(lat)
    if latitude < 23.5:
        zone, last_frost, first_frost = "Tropical (no frost)", None, None
    elif latitude < 35:
        zone, last_frost, first_frost = "Subtropical", "Feb 15", "Dec 1"
    elif latitude < 50:
        zone, last_frost, first_frost = "Temperate", "Apr 15", "Oct 15"
    else:
        zone, last_frost, first_frost = "Cold/Continental", "May 20", "Sep 25"

    weather = await get_weather(lat, lon)
    return {
        "zone": zone,
        "avgLastFrostDate": last_frost,
        "avgFirstFrostDate": first_frost,
        "recentRainfallMm": weather.get("rainLast24hMm"),
        "note": "Climate zone is estimated from latitude; use a dedicated zone database for production accuracy.",
        "isEstimate": True,
    }
