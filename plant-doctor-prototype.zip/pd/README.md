# Plant Doctor — Simple & Explainable Version

This is the simplified version of Plant Doctor.

The main user experience is kept the same, but the code is organized so a new programmer can understand the project quickly.

## Main idea

```text
Flutter app
   ↓
PlantProvider
   ↓
ApiService
   ↓
FastAPI backend (one main.py)
   ↓
AI / Weather / Plant data
```

## Why this version is easier

- The backend is one file instead of many router/service/model files.
- Flutter still separates UI, data, API, and local storage.
- Every important responsibility has one obvious file.
- The project includes a programmer guide and a complete scan-flow diagram.
- Firebase is kept as a future option but is not required just to run the app.

## Folders

### `flutter`
The Android/iOS Flutter application.

### `backend`
The Python FastAPI server. Start with `backend/main.py`.

### `firebase`
Future cloud database/security configuration.

### `frontend`
The older React Native client. It is kept for reference and is not needed for the Flutter app.

### `docs`
Simple explanations for programmers and presentations.

## Start the Flutter app

```bash
cd flutter
flutter pub get
flutter analyze
flutter run
```

## Start the backend

```bash
cd backend
pip install -r requirements.txt
copy .env.example .env
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

For an Android emulator, Flutter uses `http://10.0.2.2:8000` by default.

For a physical phone, use your computer's local IP:

```bash
flutter run --dart-define=API_BASE_URL=http://YOUR-PC-IP:8000
```

Read `docs/PROGRAMMER_GUIDE.md` before changing the code.
