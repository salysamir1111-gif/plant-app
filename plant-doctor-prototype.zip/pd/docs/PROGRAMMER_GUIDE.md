# Plant Doctor — Programmer Guide

This version keeps the **same main user experience** but reduces the number of moving parts.

## The rule of the project

If you want to change something, start here:

| What you want to change | File |
|---|---|
| App colors / visual theme | `flutter/lib/theme.dart` |
| Home page | `flutter/lib/screens/home_screen.dart` |
| Camera / scan page | `flutter/lib/screens/camera_screen.dart` |
| Plant details | `flutter/lib/screens/plant_detail_screen.dart` |
| Watering page | `flutter/lib/screens/watering_schedule_screen.dart` |
| Settings | `flutter/lib/screens/settings_screen.dart` |
| Plant data fields | `flutter/lib/models/plant.dart` |
| Plant state / actions | `flutter/lib/providers/plant_provider.dart` |
| Internet/API calls | `flutter/lib/services/api_service.dart` |
| Local saved data | `flutter/lib/services/local_storage_service.dart` |
| Backend + AI + weather | `backend/main.py` |
| Flutter packages | `flutter/pubspec.yaml` |

## Simple architecture

```text
SCREEN
  ↓
PlantProvider
  ↓
ApiService ─────→ Backend (main.py)
  ↓                    ↓
LocalStorage       Plant.id / Weather
```

### 1. Screens
The screens display the UI and respond to taps.

They should not contain large amounts of database or API logic.

### 2. PlantProvider
This is the app's central plant manager.

It stores the current list of plants and exposes actions such as:

- add a plant
- mark a plant as watered
- update health
- change notification settings
- refresh plants

### 3. ApiService
This is the only Flutter file that should know the backend URLs.

If an endpoint changes, normally edit `api_service.dart`, not every screen.

### 4. LocalStorageService
This keeps simple data on the phone so the app can still show the garden when the backend is unavailable.

### 5. Backend
The backend is intentionally one file: `backend/main.py`.

It contains:

- API routes
- simple request models
- Plant.id integration
- weather integration
- watering rules
- temporary plant storage

This is less scalable than a large production backend, but much easier to teach and modify.

## Example: change the default watering rule

Open `backend/main.py` and find:

```python
WATERING_DAYS = {
    "monstera deliciosa": 7,
    "ocimum basilicum": 3,
    "succulent": 14,
    "cactus": 21,
}
```

Change a number and restart the backend.

## Example: change the main app color

Open `flutter/lib/theme.dart` and change the value used by `AppColors.primary`.

The rest of the app uses that color automatically.

## Example: change the AI provider

The Flutter app does not need to know which AI provider is being used.

Keep the Flutter endpoint:

```text
POST /identify
```

and change the implementation inside `backend/main.py`.

This makes it possible to replace Plant.id with PlantNet or your own model later.

## Important development limitations

- The backend plant database is temporary and resets when the server restarts.
- AI results are marked as demo results when no API key is configured.
- Health checking is visual assistance, not laboratory pathogen confirmation.
- Watering recommendations are estimates, not soil-moisture measurements.
- Firebase files remain in the project as the future cloud-storage plan, but the current simple build does not require Firebase to run.
