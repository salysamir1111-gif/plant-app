# Plant Doctor — One Complete Flow

## When the user scans a plant

```text
1. User taps Scan
       ↓
2. camera_screen.dart opens the phone camera
       ↓
3. User takes a photo
       ↓
4. Flutter converts the photo to Base64
       ↓
5. ApiService sends POST /identify
       ↓
6. backend/main.py receives the image
       ↓
7. Backend calls Plant.id (when an API key exists)
       ↓
8. Backend converts the result to Plant Doctor's simple format
       ↓
9. Flutter receives IdentifyResult
       ↓
10. PlantProvider creates/saves the Plant
       ↓
11. LocalStorageService saves the plant on the phone
       ↓
12. Home screen displays the new plant
```

## When the user checks plant health

```text
Camera
  ↓
POST /disease/check
  ↓
backend/main.py
  ↓
Plant.id health analysis
  ↓
health score + findings
  ↓
PlantProvider.updateHealth()
  ↓
plant profile is updated
```

## When the user asks for watering advice

```text
Plant species + location
          ↓
ApiService
          ↓
GET /watering/schedule
          ↓
backend/main.py
          ↓
species rule + optional weather humidity
          ↓
watering estimate
          ↓
Flutter displays the recommendation
```
