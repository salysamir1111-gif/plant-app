# Plant Doctor Flutter App

The Flutter side is organized around four simple ideas:

1. **Screens** = what the user sees.
2. **PlantProvider** = the current plant data and actions.
3. **ApiService** = communication with the Python backend.
4. **LocalStorageService** = simple phone storage.

## Main files

- `lib/main.dart` — starts the app.
- `lib/app.dart` — creates the app and chooses onboarding/main screen.
- `lib/theme.dart` — colors and Material theme.
- `lib/models/plant.dart` — plant and API result data.
- `lib/providers/plant_provider.dart` — plant state and actions.
- `lib/services/api_service.dart` — backend calls.
- `lib/services/local_storage_service.dart` — local saved data.
- `lib/screens/` — all user-facing pages.
- `lib/widgets/` — small reusable UI components.

## Run

```bash
flutter pub get
flutter analyze
flutter run
```

Android emulator default:

```text
http://10.0.2.2:8000
```

Physical Android phone:

```bash
flutter run --dart-define=API_BASE_URL=http://YOUR-PC-IP:8000
```

The backend must be running first if you want the real API flow.
