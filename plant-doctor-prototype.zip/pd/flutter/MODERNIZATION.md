# Simple Version Notes

The original modernized project was kept functionally similar, but the structure was simplified for teaching and maintenance.

## What changed

- Backend router/service/model files were combined into `backend/main.py`.
- Unused Firebase and permission-handler Flutter dependencies were removed from the running app.
- Firebase configuration remains in the project as a future cloud-sync option.
- Added `docs/PROGRAMMER_GUIDE.md` and `docs/PROJECT_FLOW.md`.
- Kept the main Flutter screens, camera flow, local storage, API integration, watering estimates, and health/identification flow.

## Design principle

A programmer should be able to answer:

> "Where do I change this?"

without searching the whole project.
