import 'package:flutter/material.dart';

import 'screens/onboarding_screen.dart';
import 'screens/main_tabs_screen.dart';
import 'services/local_storage_service.dart';
import 'theme.dart';

class PlantDoctorApp extends StatelessWidget {
  const PlantDoctorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Plant Doctor',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: const AppEntry(),
    );
  }
}

class AppEntry extends StatelessWidget {
  const AppEntry({super.key});

  @override
  Widget build(BuildContext context) {
    final storage = LocalStorageService.instance;
    return storage.hasCompletedOnboarding
        ? const MainTabsScreen()
        : const OnboardingScreen();
  }
}
