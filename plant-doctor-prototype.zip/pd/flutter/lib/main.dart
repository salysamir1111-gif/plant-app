import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'providers/plant_provider.dart';
import 'services/local_storage_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final storage = LocalStorageService();
  await storage.init();

  runApp(
    ChangeNotifierProvider(
      create: (_) => PlantProvider(storage: storage)..initialize(),
      child: const PlantDoctorApp(),
    ),
  );
}
