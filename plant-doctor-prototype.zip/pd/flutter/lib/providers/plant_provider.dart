import 'package:flutter/foundation.dart';

import '../models/plant.dart';
import '../services/api_service.dart';
import '../services/local_storage_service.dart';

class PlantProvider extends ChangeNotifier {
  PlantProvider({required this.storage, ApiService? api})
      : _api = api ?? ApiService();

  final LocalStorageService storage;
  final ApiService _api;

  List<Plant> _plants = [];
  bool _loading = false;
  bool _initialized = false;
  double? lat;
  double? lon;
  bool weatherAware = true;
  bool imperialUnits = false;
  String notificationMode = 'full';
  String? errorMessage;

  List<Plant> get plants => List.unmodifiable(_plants);
  bool get loading => _loading;
  bool get initialized => _initialized;
  bool get hasLocation => lat != null && lon != null;

  int get healthyCount => _plants.where((p) => p.healthScore >= 70).length;
  int get attentionCount => _plants.where((p) => p.healthScore < 70).length;

  List<Plant> get plantsNeedingAttention =>
      _plants.where((p) => p.healthScore < 70).toList();

  int get wateringDueCount =>
      _plants.where(needsWater).length;

  Future<void> initialize() async {
    _plants = storage.loadPlants();
    lat = storage.latitude;
    lon = storage.longitude;
    weatherAware = storage.weatherAware;
    imperialUnits = storage.imperialUnits;
    notificationMode = storage.notificationMode;
    _initialized = true;
    notifyListeners();

    if (_plants.isEmpty) {
      await refreshPlants();
    }
  }

  void setLocation(double latitude, double longitude) {
    lat = latitude;
    lon = longitude;
    storage.saveLocation(latitude, longitude);
    notifyListeners();
  }

  Plant? byId(String id) {
    for (final plant in _plants) {
      if (plant.id == id) return plant;
    }
    return null;
  }

  bool needsWater(Plant plant) {
    final next = plant.nextWateringAt;
    return next == null || !DateTime.now().isBefore(next);
  }

  Future<void> refreshPlants() async {
    _loading = true;
    errorMessage = null;
    notifyListeners();

    try {
      final remote = await _api.listPlants();
      // Do not erase a user's local garden just because the development
      // server currently has no plants. Keep local data until the account
      // sync layer is connected.
      if (remote.isNotEmpty || _plants.isEmpty) {
        _plants = remote;
        await storage.savePlants(_plants);
      }
    } catch (_) {
      if (_plants.isEmpty) {
        _plants = _demoPlants();
        await storage.savePlants(_plants);
      }
      errorMessage = 'Showing saved plants. The server is unavailable.';
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<Plant> addPlant(Plant plant) async {
    Plant created;
    try {
      created = await _api.createPlant(plant);
    } catch (_) {
      created = plant.copyWith(
        name: plant.name,
        lastCheckedAt: DateTime.now(),
      );
      created = Plant(
        id: 'local-${DateTime.now().millisecondsSinceEpoch}',
        name: created.name,
        species: created.species,
        photoUrl: created.photoUrl,
        healthScore: created.healthScore,
        notificationMode: created.notificationMode,
        identifyConfidence: created.identifyConfidence,
        identifyIsDemo: created.identifyIsDemo,
        healthScoreIsEstimate: created.healthScoreIsEstimate,
        lastCheckedAt: created.lastCheckedAt,
      );
    }

    _plants = [..._plants, created];
    await storage.savePlants(_plants);
    notifyListeners();
    return created;
  }

  Future<void> markWatered(
    Plant plant, {
    int intervalDays = 7,
  }) async {
    final now = DateTime.now();
    final updated = plant.copyWith(
      lastWateredAt: now,
      nextWateringAt: now.add(Duration(days: intervalDays)),
    );
    await _replace(updated);
    try {
      await _api.updatePlant(plant.id, {
        'lastWateredAt': now.toIso8601String(),
        'nextWateringAt': updated.nextWateringAt?.toIso8601String(),
      });
    } catch (_) {
      // Local storage remains the source of truth when the API is unavailable.
    }
  }

  Future<void> updateHealth(
    String plantId,
    int score, {
    bool isEstimate = true,
  }) async {
    final plant = byId(plantId);
    if (plant == null) return;

    final checkedAt = DateTime.now();
    final updated = plant.copyWith(
      healthScore: score.clamp(0, 100),
      healthScoreIsEstimate: isEstimate,
      lastCheckedAt: checkedAt,
    );
    await _replace(updated);
    try {
      await _api.updatePlant(plantId, {
        'healthScore': updated.healthScore,
        'healthScoreIsEstimate': isEstimate,
        'lastCheckedAt': checkedAt.toIso8601String(),
      });
    } catch (_) {
      // Keep the successful local result if the API is unavailable.
    }
  }

  Future<void> setNotificationMode(String plantId, String mode) async {
    final plant = byId(plantId);
    if (plant == null) return;

    await _replace(plant.copyWith(notificationMode: mode));

    await storage.saveSettings(notificationMode: mode);
    notificationMode = mode;
    notifyListeners();

    try {
      await _api.updatePlant(plantId, {'notificationMode': mode});
    } catch (_) {}
  }


  Future<void> setNotificationModeForAll(String mode) async {
    _plants = _plants
        .map((plant) => plant.copyWith(notificationMode: mode))
        .toList();
    notificationMode = mode;
    await storage.saveSettings(notificationMode: mode);
    await storage.savePlants(_plants);
    notifyListeners();

    for (final plant in _plants) {
      try {
        await _api.updatePlant(plant.id, {'notificationMode': mode});
      } catch (_) {}
    }
  }

  Future<void> setWeatherAware(bool value) async {
    weatherAware = value;
    await storage.saveSettings(weatherAware: value);
    notifyListeners();
  }

  Future<void> setImperialUnits(bool value) async {
    imperialUnits = value;
    await storage.saveSettings(imperialUnits: value);
    notifyListeners();
  }

  Future<void> _replace(Plant updated) async {
    _plants = _plants
        .map((plant) => plant.id == updated.id ? updated : plant)
        .toList();
    await storage.savePlants(_plants);
    notifyListeners();
  }

  List<Plant> _demoPlants() => [
        const Plant(
          id: 'demo-1',
          name: 'Monstera',
          species: 'Monstera deliciosa',
          healthScore: 88,
          nextWateringAt: null,
        ),
        const Plant(
          id: 'demo-2',
          name: 'Basil',
          species: 'Ocimum basilicum',
          healthScore: 62,
          notificationMode: 'digest',
        ),
        const Plant(
          id: 'demo-3',
          name: 'Aloe Vera',
          species: 'Aloe vera',
          healthScore: 94,
        ),
      ];
}
