import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/plant.dart';
import '../providers/plant_provider.dart';
import '../services/api_service.dart';
import '../theme.dart';
import 'plant_detail_screen.dart';

class WateringScheduleScreen extends StatefulWidget {
  const WateringScheduleScreen({super.key});

  @override
  State<WateringScheduleScreen> createState() => _WateringScheduleScreenState();
}

class _WateringScheduleScreenState extends State<WateringScheduleScreen> {
  final Map<String, WateringSchedule> _schedules = {};
  bool _loaded = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_loaded) {
      _loaded = true;
      _load();
    }
  }

  Future<void> _load() async {
    final provider = context.read<PlantProvider>();
    final api = ApiService();

    for (final plant in provider.plants) {
      try {
        final schedule = await api.getWateringSchedule(
          plant.species,
          provider.lat,
          provider.lon,
        );
        if (mounted) setState(() => _schedules[plant.id] = schedule);
      } catch (_) {
        if (mounted) {
          setState(
            () => _schedules[plant.id] = const WateringSchedule(
              frequencyDays: 7,
              note: 'General estimate.',
            ),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PlantProvider>();
    final due = provider.wateringDueCount;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Care plan',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          setState(() => _schedules.clear());
          await _load();
        },
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
          children: [
            _summary(due),
            const SizedBox(height: 18),
            if (provider.plants.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(28),
                  child: Center(
                    child: Text(
                      'Add your first plant to build a care plan.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.subtext),
                    ),
                  ),
                ),
              )
            else
              ...provider.plants.map(
                (plant) => _item(
                  context,
                  provider,
                  plant,
                  provider.needsWater(plant),
                ),
              ),
            const SizedBox(height: 8),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(17),
                child: Text(
                  '💡 Watering schedules are estimates. Always check the soil and your plant’s actual condition before watering.',
                  style: TextStyle(
                    color: AppColors.subtext,
                    height: 1.45,
                    fontSize: 13,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _summary(int due) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.primaryLight,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.water_drop_rounded,
            size: 34,
            color: AppColors.primary,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Today',
                  style: TextStyle(
                    color: AppColors.subtext,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  due == 0
                      ? 'No watering checks due'
                      : '$due plant${due == 1 ? '' : 's'} need a soil check',
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _item(
    BuildContext context,
    PlantProvider provider,
    Plant plant,
    bool due,
  ) {
    final schedule = _schedules[plant.id];
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => PlantDetailScreen(plantId: plant.id),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: due
                      ? AppColors.warning.withValues(alpha: .12)
                      : AppColors.primaryLight,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.water_drop_rounded,
                  color: due ? AppColors.warning : AppColors.primary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      plant.name,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      schedule == null
                          ? 'Calculating schedule…'
                          : 'Every ${schedule.frequencyDays} days',
                      style: const TextStyle(
                        color: AppColors.subtext,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              Text(
                due ? 'CHECK' : 'OK',
                style: TextStyle(
                  color: due ? AppColors.warning : AppColors.primary,
                  fontWeight: FontWeight.w800,
                  fontSize: 11,
                ),
              ),
              const SizedBox(width: 3),
              const Icon(
                Icons.chevron_right_rounded,
                color: AppColors.subtext,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
