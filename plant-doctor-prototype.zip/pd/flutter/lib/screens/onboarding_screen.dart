import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';

import '../providers/plant_provider.dart';
import '../services/local_storage_service.dart';
import '../theme.dart';
import 'main_tabs_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  int _page = 0;
  bool _loading = false;
  String? _message;

  static const _pages = [
    (
      '🌱',
      'Meet your Plant Doctor',
      'Identify plants, understand visible symptoms, and build a care routine for your garden.',
    ),
    (
      '📸',
      'Scan instead of guessing',
      'Take a clear photo and get AI-assisted identification and visual health guidance.',
    ),
    (
      '💧',
      'Stay ahead of plant care',
      'Track watering, check plant health, and build reminders around your real routine.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final page = _pages[_page];
    final last = _page == _pages.length - 1;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 22, 24, 22),
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: _skip,
                  child: const Text('Skip'),
                ),
              ),
              const Spacer(),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 250),
                child: Container(
                  key: ValueKey(_page),
                  width: 150,
                  height: 150,
                  decoration: const BoxDecoration(
                    color: AppColors.primaryLight,
                    shape: BoxShape.circle,
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    page.$1,
                    style: const TextStyle(fontSize: 70),
                  ),
                ),
              ),
              const SizedBox(height: 36),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 200),
                child: Text(
                  page.$2,
                  key: ValueKey('${_page}-title'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                page.$3,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: AppColors.subtext,
                  height: 1.5,
                  fontSize: 15,
                ),
              ),
              const Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  _pages.length,
                  (index) => AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: index == _page ? 24 : 7,
                    height: 7,
                    decoration: BoxDecoration(
                      color: index == _page
                          ? AppColors.primary
                          : AppColors.border,
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _loading
                      ? null
                      : () {
                          if (!last) {
                            setState(() => _page++);
                          } else {
                            _finish();
                          }
                        },
                  child: _loading
                      ? const SizedBox(
                          height: 21,
                          width: 21,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Text(last ? 'Set up my garden' : 'Continue'),
                ),
              ),
              if (_message != null)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Text(
                    _message!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppColors.warning,
                      fontSize: 12,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _finish() async {
    setState(() {
      _loading = true;
      _message = null;
    });

    await _tryLocation();

    await LocalStorageService.instance.setOnboardingComplete();

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const MainTabsScreen()),
    );
  }

  Future<void> _tryLocation() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return;

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        return;
      }

      final position = await Geolocator.getCurrentPosition();
      if (!mounted) return;

      context.read<PlantProvider>().setLocation(
            position.latitude,
            position.longitude,
          );
    } catch (_) {
      // Location is optional. The app remains usable without it.
    }
  }

  Future<void> _skip() async {
    await LocalStorageService.instance.setOnboardingComplete();
    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const MainTabsScreen()),
    );
  }
}
