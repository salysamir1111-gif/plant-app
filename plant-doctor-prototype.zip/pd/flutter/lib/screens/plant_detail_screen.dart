import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/plant.dart';
import '../providers/plant_provider.dart';
import '../services/api_service.dart';
import '../theme.dart';
import '../widgets/health_score_badge.dart';
import 'camera_screen.dart';

class PlantDetailScreen extends StatefulWidget {
  const PlantDetailScreen({
    super.key,
    required this.plantId,
    this.identifyResult,
  });

  final String plantId;
  final IdentifyResult? identifyResult;

  @override
  State<PlantDetailScreen> createState() => _PlantDetailScreenState();
}

class _PlantDetailScreenState extends State<PlantDetailScreen> {
  WateringSchedule? _schedule;
  ClimateInfo? _climate;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadCarePlan();
  }

  Future<void> _loadCarePlan() async {
    final provider = context.read<PlantProvider>();
    final plant = provider.byId(widget.plantId);
    if (plant == null) return;

    try {
      _schedule = await ApiService().getWateringSchedule(
        plant.species,
        provider.lat,
        provider.lon,
      );

      if (provider.weatherAware && provider.hasLocation) {
        _climate = await ApiService().getClimateInfo(
          provider.lat,
          provider.lon,
        );
      }
    } catch (_) {
      _schedule = const WateringSchedule(
        frequencyDays: 7,
        note: 'Using a general estimate.',
      );
    }

    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PlantProvider>();
    final plant = provider.byId(widget.plantId);

    if (plant == null) {
      return const Scaffold(
        body: Center(child: Text('Plant not found.')),
      );
    }

    final health = healthLabelFor(plant.healthScore);
    final next = plant.nextWateringAt;
    final needsWater = provider.needsWater(plant);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Plant report',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: [
          IconButton(
            tooltip: 'Reminder settings',
            onPressed: () => _showReminderSettings(plant),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 36),
        children: [
          _hero(plant),
          const SizedBox(height: 17),
          Text(
            plant.name,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 3),
          Text(
            plant.species,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: AppColors.subtext,
              fontStyle: FontStyle.italic,
            ),
          ),
          const SizedBox(height: 10),
          Center(child: HealthScoreBadge(score: plant.healthScore)),
          if (plant.identifyConfidence != null) ...[
            const SizedBox(height: 8),
            Center(
              child: Text(
                'Identification confidence: ${(plant.identifyConfidence! * 100).round()}%',
                style: const TextStyle(
                  color: AppColors.subtext,
                  fontSize: 12,
                ),
              ),
            ),
          ],
          const SizedBox(height: 18),
          _healthCard(plant, health),
          const SizedBox(height: 12),
          _waterCard(provider, plant, next, needsWater),
          const SizedBox(height: 12),
          if (_climate != null) ...[
            _climateCard(_climate!),
            const SizedBox(height: 12),
          ],
          if (widget.identifyResult?.careTips != null) ...[
            _infoCard(
              'AI care advice',
              Icons.auto_awesome_rounded,
              widget.identifyResult!.careTips!,
            ),
            const SizedBox(height: 12),
          ],
          _infoCard(
            'Light',
            Icons.wb_sunny_outlined,
            'Aim for bright, suitable light for this species. Avoid sudden changes and harsh heat when possible.',
          ),
          const SizedBox(height: 12),
          _checkupCard(plant),
          const SizedBox(height: 12),
          _notificationCard(provider, plant),
          const SizedBox(height: 12),
          _disclaimer(plant),
        ],
      ),
    );
  }

  Widget _hero(Plant plant) {
    final path = plant.photoUrl;
    return Container(
      height: 225,
      decoration: BoxDecoration(
        color: AppColors.primaryLight,
        borderRadius: BorderRadius.circular(24),
      ),
      clipBehavior: Clip.antiAlias,
      child: path != null && path.isNotEmpty
          ? Image.file(
              File(path),
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Center(
                child: Text('🌿', style: TextStyle(fontSize: 70)),
              ),
            )
          : const Center(
              child: Text('🌿', style: TextStyle(fontSize: 70)),
            ),
    );
  }

  Widget _healthCard(Plant plant, HealthLabel health) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            SizedBox(
              width: 80,
              height: 80,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CircularProgressIndicator(
                    value: plant.healthScore / 100,
                    strokeWidth: 8,
                    backgroundColor: AppColors.border,
                    color: health.color,
                  ),
                  Text(
                    '${plant.healthScore}',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Health status',
                    style: TextStyle(
                      color: AppColors.subtext,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    health.label,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: health.color,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    plant.lastCheckedAt == null
                        ? 'No health check recorded yet.'
                        : 'Latest check: ${_dateText(plant.lastCheckedAt)}',
                    style: const TextStyle(
                      color: AppColors.subtext,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _waterCard(
    PlantProvider provider,
    Plant plant,
    DateTime? next,
    bool needsWater,
  ) {
    final days = _schedule?.frequencyDays ?? 7;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _bubble(Icons.water_drop_rounded, AppColors.primary),
                const SizedBox(width: 11),
                const Text(
                  'Watering',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                ),
              ],
            ),
            const SizedBox(height: 13),
            Text(
              needsWater
                  ? '💧 Check the soil today'
                  : 'Next check: ${_dateText(next)}',
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              _loading
                  ? 'Calculating your local care estimate…'
                  : 'Every $days days · ${_schedule?.note ?? 'Check soil before watering.'}',
              style: const TextStyle(
                color: AppColors.subtext,
                fontSize: 12,
                height: 1.4,
              ),
            ),
            if (_schedule?.isEstimate != false) ...[
              const SizedBox(height: 7),
              const Text(
                'Estimate only — your soil condition comes first.',
                style: TextStyle(
                  color: AppColors.warning,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
            const SizedBox(height: 13),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => provider.markWatered(
                  plant,
                  intervalDays: days,
                ),
                icon: const Icon(Icons.check_rounded),
                label: const Text('Mark as watered'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _climateCard(ClimateInfo climate) {
    return _infoCard(
      'Local conditions',
      Icons.cloud_outlined,
      climate.note ??
          'Weather information can help adjust a watering estimate. It is not a substitute for checking your soil.',
    );
  }

  Widget _checkupCard(Plant plant) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Weekly check-up',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 5),
            const Text(
              'Take another photo to update the visible health estimate and keep a regular care routine.',
              style: TextStyle(
                color: AppColors.subtext,
                fontSize: 13,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 13),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => CameraScreen(checkPlantId: plant.id),
                  ),
                ),
                icon: const Icon(Icons.camera_alt_outlined),
                label: const Text('Take check-up photo'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _notificationCard(PlantProvider provider, Plant plant) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Reminders',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              initialValue: plant.notificationMode,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                isDense: true,
              ),
              items: const [
                DropdownMenuItem(
                  value: 'full',
                  child: Text('Full reminders'),
                ),
                DropdownMenuItem(
                  value: 'digest',
                  child: Text('Weekly digest'),
                ),
                DropdownMenuItem(
                  value: 'off',
                  child: Text('On-demand only'),
                ),
              ],
              onChanged: (value) {
                if (value != null) {
                  provider.setNotificationMode(plant.id, value);
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoCard(String title, IconData icon, String text) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _bubble(icon, AppColors.primary),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    text,
                    style: const TextStyle(
                      color: AppColors.subtext,
                      height: 1.45,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _bubble(IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(9),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .11),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(icon, color: color),
    );
  }

  Widget _disclaimer(Plant plant) {
    final demo = plant.identifyIsDemo || plant.healthScoreIsEstimate;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.primaryLight,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        demo
            ? 'Demo/estimate mode: AI results are examples or visual estimates until a real analysis service is connected.'
            : 'Plant Doctor provides visual guidance, not laboratory diagnosis. If a problem is severe or spreading, consult a local plant specialist.',
        style: const TextStyle(
          color: AppColors.subtext,
          fontSize: 11,
          height: 1.45,
        ),
      ),
    );
  }

  Future<void> _showReminderSettings(Plant plant) async {
    final provider = context.read<PlantProvider>();

    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Reminder mode',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 12),
            ...NotificationMode.values.map(
              (mode) => ListTile(
                leading: Icon(
                  mode == NotificationMode.full
                      ? Icons.notifications_active
                      : mode == NotificationMode.digest
                          ? Icons.calendar_month
                          : Icons.notifications_off,
                ),
                title: Text(mode.label),
                subtitle: Text(mode.description),
                trailing: plant.notificationMode == mode.key
                    ? const Icon(
                        Icons.check,
                        color: AppColors.primary,
                      )
                    : null,
                onTap: () {
                  provider.setNotificationMode(plant.id, mode.key);
                  Navigator.pop(context);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _dateText(DateTime? date) {
    if (date == null) return 'Not scheduled yet';
    return '${date.day}/${date.month}/${date.year}';
  }
}
