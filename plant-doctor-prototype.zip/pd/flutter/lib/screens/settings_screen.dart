import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/plant_provider.dart';
import '../theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PlantProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Settings',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
        children: [
          _profileHeader(),
          const SizedBox(height: 22),
          _title('Notifications'),
          Card(
            child: Column(
              children: [
                RadioGroup<String>(
                  groupValue: provider.notificationMode,
                  onChanged: (value) {
                    if (value != null) {
                      provider.setNotificationModeForAll(value);
                    }
                  },
                  child: Column(
                    children: [
                      for (final mode in NotificationMode.values)
                        RadioListTile<String>(
                          value: mode.key,
                          activeColor: AppColors.primary,
                          title: Text(
                            mode.label,
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 14,
                            ),
                          ),
                          subtitle: Text(
                            mode.description,
                            style: const TextStyle(
                              fontSize: 12,
                              color: AppColors.subtext,
                            ),
                          ),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          _title('Smart care'),
          Card(
            child: Column(
              children: [
                SwitchListTile(
                  value: provider.weatherAware,
                  onChanged: provider.setWeatherAware,
                  activeColor: AppColors.primary,
                  title: const Text(
                    'Weather-aware advice',
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                  ),
                  subtitle: const Text(
                    'Use climate information when available.',
                    style: TextStyle(fontSize: 12, color: AppColors.subtext),
                  ),
                  secondary: const Icon(
                    Icons.cloud_outlined,
                    color: AppColors.primary,
                  ),
                ),
                const Divider(height: 1),
                SwitchListTile(
                  value: provider.imperialUnits,
                  onChanged: provider.setImperialUnits,
                  activeColor: AppColors.primary,
                  title: const Text(
                    'Use imperial units',
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                  ),
                  subtitle: const Text(
                    'Show °F and inches instead of metric units.',
                    style: TextStyle(fontSize: 12, color: AppColors.subtext),
                  ),
                  secondary: const Icon(
                    Icons.straighten_rounded,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          _title('About Plant Doctor'),
          Card(
            child: Column(
              children: const [
                ListTile(
                  leading: Icon(
                    Icons.auto_awesome_rounded,
                    color: AppColors.primary,
                  ),
                  title: Text('AI-assisted analysis'),
                  subtitle: Text(
                    'Photo results are visual estimates, not laboratory diagnoses.',
                  ),
                ),
                Divider(height: 1),
                ListTile(
                  leading: Icon(
                    Icons.privacy_tip_outlined,
                    color: AppColors.primary,
                  ),
                  title: Text('Privacy'),
                  subtitle: Text(
                    'Only use photos and location data you are comfortable sharing.',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _profileHeader() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.primaryLight, AppColors.mint],
        ),
        borderRadius: BorderRadius.circular(22),
      ),
      child: const Row(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: AppColors.primary,
            child: Icon(
              Icons.local_florist_rounded,
              color: Colors.white,
              size: 28,
            ),
          ),
          SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Plant Doctor',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: 3),
                Text(
                  'Your personal garden assistant',
                  style: TextStyle(
                    color: AppColors.subtext,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _title(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 3, bottom: 8),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w800,
          color: AppColors.subtext,
        ),
      ),
    );
  }
}
