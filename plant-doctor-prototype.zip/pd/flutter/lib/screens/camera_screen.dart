import 'dart:convert';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/plant.dart';
import '../providers/plant_provider.dart';
import '../services/api_service.dart';
import '../theme.dart';
import 'plant_detail_screen.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key, this.checkPlantId});

  final String? checkPlantId;

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  CameraController? _controller;
  Future<void>? _initialization;
  bool _busy = false;
  String? _error;

  bool get isCheckup => widget.checkPlantId != null;

  @override
  void initState() {
    super.initState();
    _setupCamera();
  }

  Future<void> _setupCamera() async {
    try {
      final cameras = await availableCameras();

      if (cameras.isEmpty) {
        if (mounted) {
          setState(() => _error = 'No camera was found on this device.');
        }
        return;
      }

      final camera = cameras.firstWhere(
        (item) => item.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );

      final controller = CameraController(
        camera,
        ResolutionPreset.high,
        enableAudio: false,
      );

      _controller = controller;
      _initialization = controller.initialize();

      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) {
        setState(
          () => _error =
              'Camera unavailable. Please check camera permission and try again.',
        );
      }
    }
  }

  Future<void> _capture() async {
    final controller = _controller;
    if (controller == null || _busy || !controller.value.isInitialized) return;

    setState(() => _busy = true);

    try {
      final photo = await controller.takePicture();
      final bytes = await File(photo.path).readAsBytes();
      final base64Image = base64Encode(bytes);
      final api = ApiService();

      if (isCheckup) {
        final result = await api.checkPlantHealth(
          widget.checkPlantId!,
          base64Image,
        );

        final score = ((result['healthScore'] as num?)?.toInt() ?? 75)
            .clamp(0, 100);
        final isEstimate = result['isDemo'] != false;

        await context.read<PlantProvider>().updateHealth(
              widget.checkPlantId!,
              score,
              isEstimate: isEstimate,
            );

        if (!mounted) return;
        await _showCheckupResult(result, score);
        return;
      }

      final result = await api.identifyPlant(base64Image);

      final created = await context.read<PlantProvider>().addPlant(
            Plant(
              id: '',
              name: result.commonName.isNotEmpty
                  ? result.commonName
                  : 'New plant',
              species: result.species,
              photoUrl: photo.path,
              healthScore: 100,
              identifyConfidence: result.confidence,
              identifyIsDemo: result.isDemo,
              healthScoreIsEstimate: true,
              lastCheckedAt: DateTime.now(),
            ),
          );

      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => PlantDetailScreen(
            plantId: created.id,
            identifyResult: result,
          ),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Could not analyze the photo'),
          content: Text(
            'The photo was captured, but the AI service could not be reached.\n\n$error',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        ),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _showCheckupResult(
    Map<String, dynamic> result,
    int score,
  ) async {
    final summary = result['summary']?.toString() ??
        'The latest visual check has been saved to your plant profile.';

    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 4, 22, 30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.auto_awesome_rounded, color: AppColors.primary),
                const SizedBox(width: 9),
                const Text(
                  'Check-up complete',
                  style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Text(
              '$score/100',
              style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 3),
            const Text(
              'Latest visual health estimate',
              style: TextStyle(color: AppColors.subtext),
            ),
            const SizedBox(height: 14),
            Text(
              summary,
              style: const TextStyle(
                color: AppColors.subtext,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.popUntil(
                  context,
                  (route) => route.isFirst,
                ),
                child: const Text('Done'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Text(
              _error!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, height: 1.5),
            ),
          ),
        ),
      );
    }

    final controller = _controller;
    final initialization = _initialization;

    if (controller == null || initialization == null) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: CircularProgressIndicator(color: Colors.white),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(
          isCheckup ? 'Plant check-up' : 'Scan a plant',
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: [
          IconButton(
            onPressed: _showTip,
            icon: const Icon(Icons.info_outline_rounded),
          ),
        ],
      ),
      body: FutureBuilder<void>(
        future: initialization,
        builder: (_, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(
              child: CircularProgressIndicator(color: Colors.white),
            );
          }

          return Stack(
            fit: StackFit.expand,
            children: [
              CameraPreview(controller),
              IgnorePointer(child: CustomPaint(painter: _ScanFramePainter())),
              Positioned(
                top: 20,
                left: 24,
                right: 24,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 11,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: .48),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(
                    isCheckup
                        ? 'Center the leaves and show the affected area clearly.'
                        : 'Use natural light and place the whole plant or a clear leaf in the frame.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      height: 1.35,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 20,
                right: 20,
                bottom: 32,
                child: Column(
                  children: [
                    if (_busy)
                      const Padding(
                        padding: EdgeInsets.only(bottom: 14),
                        child: Text(
                          'Plant Doctor is analyzing…',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    GestureDetector(
                      onTap: _capture,
                      child: Container(
                        width: 82,
                        height: 82,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppColors.primary,
                          border: Border.all(
                            color: Colors.white,
                            width: 5,
                          ),
                        ),
                        child: _busy
                            ? const Padding(
                                padding: EdgeInsets.all(24),
                                child: CircularProgressIndicator(
                                  strokeWidth: 3,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(
                                Icons.camera_alt_rounded,
                                color: Colors.white,
                                size: 34,
                              ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Tap to analyze',
                      style: TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  void _showTip() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (_) => const Padding(
        padding: EdgeInsets.fromLTRB(22, 4, 22, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Better scans = better advice',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
            ),
            SizedBox(height: 12),
            Text(
              'Use natural light, avoid blurry photos, and show affected leaves clearly. Plant Doctor provides a visual assessment; a photo alone cannot confirm a specific pathogen.',
              style: TextStyle(
                color: AppColors.subtext,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ScanFramePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withValues(alpha: .88)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    final rect = Rect.fromCenter(
      center: Offset(size.width / 2, size.height * .43),
      width: size.width * .72,
      height: size.height * .46,
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(26)),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
