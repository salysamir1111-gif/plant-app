import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/plant.dart';

class LocalStorageService {
  static LocalStorageService? _instance;
  static LocalStorageService get instance => _instance ??= LocalStorageService();

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
    _instance = this;
  }

  SharedPreferences get prefs {
    final value = _prefs;
    if (value == null) {
      throw StateError('LocalStorageService.init() must be called first.');
    }
    return value;
  }

  bool get hasCompletedOnboarding =>
      prefs.getBool('onboarding_complete') ?? false;

  Future<void> setOnboardingComplete() async {
    await prefs.setBool('onboarding_complete', true);
  }

  List<Plant> loadPlants() {
    final raw = prefs.getString('plants');
    if (raw == null || raw.isEmpty) return [];

    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list
          .whereType<Map>()
          .map((item) => Plant.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> savePlants(List<Plant> plants) async {
    await prefs.setString(
      'plants',
      jsonEncode(plants.map((plant) => plant.toJson()).toList()),
    );
  }

  double? get latitude => prefs.getDouble('latitude');
  double? get longitude => prefs.getDouble('longitude');

  Future<void> saveLocation(double lat, double lon) async {
    await prefs.setDouble('latitude', lat);
    await prefs.setDouble('longitude', lon);
  }

  bool get weatherAware => prefs.getBool('weather_aware') ?? true;
  bool get imperialUnits => prefs.getBool('imperial_units') ?? false;
  String get notificationMode => prefs.getString('notification_mode') ?? 'full';

  Future<void> saveSettings({
    bool? weatherAware,
    bool? imperialUnits,
    String? notificationMode,
  }) async {
    if (weatherAware != null) await prefs.setBool('weather_aware', weatherAware);
    if (imperialUnits != null) await prefs.setBool('imperial_units', imperialUnits);
    if (notificationMode != null) {
      await prefs.setString('notification_mode', notificationMode);
    }
  }
}
