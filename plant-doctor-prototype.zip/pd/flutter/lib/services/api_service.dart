import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/plant.dart';

class ApiService {
  ApiService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8000',
  );

  static const Duration _timeout = Duration(seconds: 25);

  Future<Map<String, dynamic>> _post(
    String path,
    Map<String, dynamic> body,
  ) async {
    final response = await _client
        .post(
          Uri.parse('$baseUrl$path'),
          headers: const {'Content-Type': 'application/json'},
          body: jsonEncode(body),
        )
        .timeout(_timeout);

    return _decodeObject(response, path);
  }

  Future<dynamic> _get(String path) async {
    final response = await _client
        .get(Uri.parse('$baseUrl$path'))
        .timeout(_timeout);

    if (response.statusCode >= 400) {
      throw Exception('API $path failed (${response.statusCode}).');
    }
    return jsonDecode(response.body);
  }

  Future<Map<String, dynamic>> _patch(
    String path,
    Map<String, dynamic> body,
  ) async {
    final response = await _client
        .patch(
          Uri.parse('$baseUrl$path'),
          headers: const {'Content-Type': 'application/json'},
          body: jsonEncode(body),
        )
        .timeout(_timeout);

    return _decodeObject(response, path);
  }

  Map<String, dynamic> _decodeObject(http.Response response, String path) {
    if (response.statusCode >= 400) {
      throw Exception('API $path failed (${response.statusCode}).');
    }
    final decoded = jsonDecode(response.body);
    if (decoded is! Map) throw Exception('Unexpected API response from $path.');
    return Map<String, dynamic>.from(decoded);
  }

  Future<IdentifyResult> identifyPlant(String imageBase64) async {
    final json = await _post('/identify', {'image_base64': imageBase64});
    return IdentifyResult.fromJson(json);
  }

  Future<Map<String, dynamic>> checkPlantHealth(
    String plantId,
    String imageBase64,
  ) {
    return _post('/disease/check', {
      'plant_id': plantId,
      'image_base64': imageBase64,
    });
  }

  Future<WateringSchedule> getWateringSchedule(
    String species,
    double? lat,
    double? lon,
  ) async {
    final query =
        'species=${Uri.encodeComponent(species)}&lat=${lat ?? ''}&lon=${lon ?? ''}';
    final json = await _get('/watering/schedule?$query');
    return WateringSchedule.fromJson(
      Map<String, dynamic>.from(json as Map),
    );
  }

  Future<ClimateInfo> getClimateInfo(double? lat, double? lon) async {
    final json = await _get('/weather/climate?lat=${lat ?? ''}&lon=${lon ?? ''}');
    return ClimateInfo.fromJson(Map<String, dynamic>.from(json as Map));
  }

  Future<List<Plant>> listPlants() async {
    final json = await _get('/plants');
    if (json is! List) throw Exception('Unexpected plants response.');
    return json
        .whereType<Map>()
        .map((item) => Plant.fromJson(Map<String, dynamic>.from(item)))
        .toList();
  }

  Future<Plant> createPlant(Plant plant) async {
    final json = await _post('/plants', {
      'name': plant.name,
      'species': plant.species,
      'photoUrl': plant.photoUrl,
      'healthScore': plant.healthScore,
      'notificationMode': plant.notificationMode,
      'identifyConfidence': plant.identifyConfidence,
      'identifyIsDemo': plant.identifyIsDemo,
      'healthScoreIsEstimate': plant.healthScoreIsEstimate,
      'lastWateredAt': plant.lastWateredAt?.toIso8601String(),
      'nextWateringAt': plant.nextWateringAt?.toIso8601String(),
      'lastCheckedAt': plant.lastCheckedAt?.toIso8601String(),
    });
    return Plant.fromJson(json);
  }

  Future<Plant> updatePlant(String id, Map<String, dynamic> patch) async {
    final json = await _patch('/plants/$id', patch);
    return Plant.fromJson(json);
  }

  void dispose() => _client.close();
}
