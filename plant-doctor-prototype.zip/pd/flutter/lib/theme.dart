import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF2E7D32);
  static const primaryDark = Color(0xFF1B5E20);
  static const primaryLight = Color(0xFFE8F5E9);
  static const mint = Color(0xFFF1F8F2);
  static const accent = Color(0xFF66BB6A);
  static const warning = Color(0xFFFB8C00);
  static const danger = Color(0xFFE53935);
  static const text = Color(0xFF172117);
  static const subtext = Color(0xFF6B746B);
  static const background = Color(0xFFF6F9F5);
  static const card = Colors.white;
  static const border = Color(0xFFE1E8E0);
}

ThemeData buildAppTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.primary,
    brightness: Brightness.light,
  ).copyWith(
    primary: AppColors.primary,
    onPrimary: Colors.white,
    surface: AppColors.card,
    onSurface: AppColors.text,
  );

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: AppColors.background,
    fontFamily: 'Roboto',
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.background,
      foregroundColor: AppColors.text,
      elevation: 0,
      centerTitle: false,
      scrolledUnderElevation: 0,
    ),
    cardTheme: CardThemeData(
      color: AppColors.card,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: AppColors.border),
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        minimumSize: const Size(0, 52),
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        textStyle: const TextStyle(fontWeight: FontWeight.w700),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: AppColors.primary,
        minimumSize: const Size(0, 48),
        side: const BorderSide(color: AppColors.border),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: const TextStyle(fontWeight: FontWeight.w700),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.mint,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.border),
      ),
    ),
  );
}

class HealthLabel {
  final String label;
  final Color color;
  const HealthLabel(this.label, this.color);
}

HealthLabel healthLabelFor(int score) {
  if (score >= 90) return const HealthLabel('Thriving', AppColors.primary);
  if (score >= 70) return const HealthLabel('Healthy', AppColors.accent);
  if (score >= 50) return const HealthLabel('Needs attention', AppColors.warning);
  return const HealthLabel('At risk', AppColors.danger);
}

enum NotificationMode { full, digest, off }

extension NotificationModeX on NotificationMode {
  String get key => switch (this) {
        NotificationMode.full => 'full',
        NotificationMode.digest => 'digest',
        NotificationMode.off => 'off',
      };

  String get label => switch (this) {
        NotificationMode.full => 'Full reminders',
        NotificationMode.digest => 'Weekly digest',
        NotificationMode.off => 'On-demand only',
      };

  String get description => switch (this) {
        NotificationMode.full => 'Watering and important plant alerts',
        NotificationMode.digest => 'One combined summary each week',
        NotificationMode.off => 'No automatic notifications',
      };

  static NotificationMode fromKey(String key) => switch (key) {
        'digest' => NotificationMode.digest,
        'off' => NotificationMode.off,
        _ => NotificationMode.full,
      };
}
