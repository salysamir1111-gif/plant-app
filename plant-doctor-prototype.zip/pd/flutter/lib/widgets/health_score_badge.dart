import 'package:flutter/material.dart';

import '../theme.dart';

class HealthScoreBadge extends StatelessWidget {
  const HealthScoreBadge({super.key, required this.score});

  final int score;

  @override
  Widget build(BuildContext context) {
    final info = healthLabelFor(score);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: info.color.withValues(alpha: .11),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Text(
        '$score/100',
        style: TextStyle(
          color: info.color,
          fontSize: 11,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}
