import 'dart:io';

import 'package:flutter/material.dart';

import '../models/plant.dart';
import '../theme.dart';
import 'health_score_badge.dart';

class PlantCard extends StatelessWidget {
  const PlantCard({
    super.key,
    required this.plant,
    required this.onTap,
  });

  final Plant plant;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final health = healthLabelFor(plant.healthScore);
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              _thumbnail(),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      plant.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      plant.species,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.subtext,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        HealthScoreBadge(score: plant.healthScore),
                        const SizedBox(width: 7),
                        Flexible(
                          child: Text(
                            health.label,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: health.color,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.chevron_right_rounded,
                color: AppColors.subtext,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _thumbnail() {
    final path = plant.photoUrl;
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 72,
        height: 72,
        color: AppColors.primaryLight,
        alignment: Alignment.center,
        child: path != null && path.isNotEmpty
            ? Image.file(
                File(path),
                width: 72,
                height: 72,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Text(
                  '🌿',
                  style: TextStyle(fontSize: 30),
                ),
              )
            : const Text('🌿', style: TextStyle(fontSize: 30)),
      ),
    );
  }
}
