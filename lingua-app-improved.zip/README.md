# Lingua — Learn to speak. Learn to code.

A lightweight, single-file learning app. Open `lingua.html` in a modern browser; no install or server is required. Progress is saved locally in that browser.

## What's included
- 30 spoken-language courses and 7 programming-language courses
- Short lessons with vocabulary, listening, matching, typing, sentence building, and code exercises
- XP, daily streaks, lesson stars, weak-answer practice, and local progress saving
- Auto/light/dark themes, flashcards, keyboard shortcuts, and spoken-language region filtering
- Responsive layout and accessible labels on key controls

## Improvements in this build
- Safely normalizes saved progress so malformed or older browser storage is less likely to break the app.
- Resetting progress now stops the home-screen ticker timers and cancels speech before rerendering, preventing duplicate background timers/audio.
- Reset control has an explicit button type and polite status announcement.

## Run it
1. Extract the ZIP.
2. Open `lingua.html` in Chrome, Edge, Firefox, or another modern browser.
3. Keep browser storage enabled if you want progress to persist.

Speech playback depends on browser and operating-system voice support. Google Fonts are optional; fallback fonts are included, so the app can still render without them.

## Progress and privacy
Progress is stored in `localStorage` on the current browser/device. It does not automatically sync across devices. Use **Reset progress** on the home screen to erase it (confirmation required).

## Content and limitations
This build includes 30 spoken languages and 7 programming languages. Coverage and phrasing vary by course; treat lessons as beginner practice, not as a substitute for a full language or programming curriculum. Some features such as speech can behave differently between browsers.

## Editing
Course data is in the `HUMAN` and `CODE` arrays in `lingua.html`. Shared lesson-generation and rendering functions are in the same file. For a small, no-build app this keeps setup simple, though a future larger version could split data, styles, and JavaScript into separate files.

## License
Educational / personal use.
