import 'package:google_mobile_ads/google_mobile_ads.dart';

import 'ad_helper.dart';

class AdService {
  AdService._();

  static final AdService instance = AdService._();

  InterstitialAd? _interstitialAd;
  int _successfulAnalyses = 0;

  Future<void> initialize() async {
    await MobileAds.instance.initialize();
    _loadInterstitial();
  }

  void _loadInterstitial() {
    InterstitialAd.load(
      adUnitId: AdHelper.interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (InterstitialAd ad) {
          _interstitialAd = ad;
        },
        onAdFailedToLoad: (LoadAdError error) {
          _interstitialAd = null;
        },
      ),
    );
  }

  void recordSuccessfulAnalysis() {
    _successfulAnalyses++;
  }

  bool get shouldShowInterstitial =>
      _successfulAnalyses >= 5 && _interstitialAd != null;

  Future<void> showInterstitialIfDue() async {
    final ad = _interstitialAd;

    if (_successfulAnalyses < 5 || ad == null) {
      return;
    }

    _interstitialAd = null;
    _successfulAnalyses = 0;

    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (InterstitialAd ad) {
        ad.dispose();
        _loadInterstitial();
      },
      onAdFailedToShowFullScreenContent: (InterstitialAd ad, AdError error) {
        ad.dispose();
        _loadInterstitial();
      },
    );

    await ad.show();
  }
}
