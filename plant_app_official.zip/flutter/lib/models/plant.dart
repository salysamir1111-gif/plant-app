class Plant {
  final String id;
  final String name;
  final String species;
  final String? photoUrl;
  final int healthScore;
  final String notificationMode;
  final double? identifyConfidence;
  final bool identifyIsDemo;
  final bool healthScoreIsEstimate;
  final DateTime? lastWateredAt;
  final DateTime? nextWateringAt;
  final DateTime? lastCheckedAt;

  const Plant({
    required this.id,
    required this.name,
    required this.species,
    this.photoUrl,
    this.healthScore = 100,
    this.notificationMode = 'full',
    this.identifyConfidence,
    this.identifyIsDemo = false,
    this.healthScoreIsEstimate = true,
    this.lastWateredAt,
    this.nextWateringAt,
    this.lastCheckedAt,
  });

  factory Plant.fromJson(Map<String, dynamic> json) => Plant(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? 'Unknown plant',
        species: json['species']?.toString() ?? 'Unknown species',
        photoUrl: json['photoUrl']?.toString(),
        healthScore: (((json['healthScore'] as num?)?.toInt() ?? 100).clamp(0, 100)).toInt(),
        notificationMode: json['notificationMode']?.toString() ?? 'full',
        identifyConfidence: (json['identifyConfidence'] as num?)?.toDouble(),
        identifyIsDemo: json['identifyIsDemo'] == true,
        healthScoreIsEstimate: json['healthScoreIsEstimate'] != false,
        lastWateredAt: _date(json['lastWateredAt']),
        nextWateringAt: _date(json['nextWateringAt']),
        lastCheckedAt: _date(json['lastCheckedAt']),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'species': species,
        'photoUrl': photoUrl,
        'healthScore': healthScore,
        'notificationMode': notificationMode,
        'identifyConfidence': identifyConfidence,
        'identifyIsDemo': identifyIsDemo,
        'healthScoreIsEstimate': healthScoreIsEstimate,
        'lastWateredAt': lastWateredAt?.toIso8601String(),
        'nextWateringAt': nextWateringAt?.toIso8601String(),
        'lastCheckedAt': lastCheckedAt?.toIso8601String(),
      };

  Plant copyWith({
    String? name,
    String? species,
    String? photoUrl,
    int? healthScore,
    String? notificationMode,
    double? identifyConfidence,
    bool? identifyIsDemo,
    bool? healthScoreIsEstimate,
    DateTime? lastWateredAt,
    DateTime? nextWateringAt,
    DateTime? lastCheckedAt,
  }) {
    return Plant(
      id: id,
      name: name ?? this.name,
      species: species ?? this.species,
      photoUrl: photoUrl ?? this.photoUrl,
      healthScore: healthScore ?? this.healthScore,
      notificationMode: notificationMode ?? this.notificationMode,
      identifyConfidence: identifyConfidence ?? this.identifyConfidence,
      identifyIsDemo: identifyIsDemo ?? this.identifyIsDemo,
      healthScoreIsEstimate: healthScoreIsEstimate ?? this.healthScoreIsEstimate,
      lastWateredAt: lastWateredAt ?? this.lastWateredAt,
      nextWateringAt: nextWateringAt ?? this.nextWateringAt,
      lastCheckedAt: lastCheckedAt ?? this.lastCheckedAt,
    );
  }

  static DateTime? _date(dynamic value) {
    if (value is String) return DateTime.tryParse(value);
    return null;
  }
}

class IdentifyResult {
  final String species;
  final String commonName;
  final double confidence;
  final String? careTips;
  final bool isDemo;

  const IdentifyResult({
    required this.species,
    required this.commonName,
    required this.confidence,
    this.careTips,
    this.isDemo = false,
  });

  factory IdentifyResult.fromJson(Map<String, dynamic> json) => IdentifyResult(
        species: json['species']?.toString() ?? 'Unknown species',
        commonName: json['commonName']?.toString() ?? 'Unknown plant',
        confidence: (json['confidence'] as num?)?.toDouble() ?? 0,
        careTips: json['careTips']?.toString(),
        isDemo: json['isDemo'] == true,
      );
}

class WateringSchedule {
  final int frequencyDays;
  final String? note;
  final bool isEstimate;

  const WateringSchedule({
    required this.frequencyDays,
    this.note,
    this.isEstimate = true,
  });

  factory WateringSchedule.fromJson(Map<String, dynamic> json) =>
      WateringSchedule(
        frequencyDays: (((json['frequencyDays'] as num?)?.toInt() ?? 7).clamp(1, 60)).toInt(),
        note: json['note']?.toString(),
        isEstimate: json['isEstimate'] != false,
      );
}

class ClimateInfo {
  final String? zone;
  final double? recentRainfallMm;
  final String? note;
  final bool isEstimate;

  const ClimateInfo({
    this.zone,
    this.recentRainfallMm,
    this.note,
    this.isEstimate = true,
  });

  factory ClimateInfo.fromJson(Map<String, dynamic> json) => ClimateInfo(
        zone: json['zone']?.toString(),
        recentRainfallMm: (json['recentRainfallMm'] as num?)?.toDouble(),
        note: json['note']?.toString(),
        isEstimate: json['isEstimate'] != false,
      );
}
