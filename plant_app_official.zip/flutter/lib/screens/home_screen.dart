import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/plant.dart';
import '../providers/plant_provider.dart';
import '../theme.dart';
import '../widgets/plant_card.dart';
import '../widgets/section_title.dart';
import '../widgets/plant_doctor_banner_ad.dart';
import 'camera_screen.dart';
import 'plant_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => context.read<PlantProvider>().refreshPlants(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<PlantProvider>();
    final plants = provider.plants;
    final attention = provider.plantsNeedingAttention.isEmpty
        ? null
        : provider.plantsNeedingAttention.first;

    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Plant Doctor',
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900),
            ),
            Text(
              'Your garden, looked after.',
              style: TextStyle(fontSize: 12, color: AppColors.subtext),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Scan plant',
            onPressed: () => _openScanner(),
            icon: const Icon(Icons.center_focus_strong_rounded),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: provider.loading && plants.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: provider.refreshPlants,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
                children: [
                  const Text(
                    'Good morning 👋',
                    style: TextStyle(
                      fontSize: 16,
                      color: AppColors.subtext,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 16),
                  _gardenSummary(provider),
                  const SizedBox(height: 14),
                  _todayCard(provider, attention),
                  const SizedBox(height: 14),
                  _scanBanner(),
                  const SizedBox(height: 24),
                  SectionTitle(
                    title: 'Your plants',
                    action: plants.isEmpty ? null : '${plants.length} total',
                  ),
                  const SizedBox(height: 8),
                  if (plants.isEmpty)
                    _emptyState()
                  else
                    ...plants.map(
                      (plant) => PlantCard(
                        plant: plant,
                        onTap: () => _openPlant(plant.id),
                      ),
                    ),
                  const PlantDoctorBannerAd(),
                ],
              ),
            ),
    );
  }

  Widget _gardenSummary(PlantProvider p) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primary, AppColors.primaryDark],
        ),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Your garden today',
                  style: TextStyle(color: Colors.white70, fontSize: 13),
                ),
                const SizedBox(height: 4),
                Text(
                  '${p.plants.length}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 36,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const Text(
                  'plants being cared for',
                  style: TextStyle(color: Colors.white, fontSize: 14),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              _stat('${p.healthyCount}', 'Healthy', Icons.favorite_rounded),
              const SizedBox(height: 9),
              _stat(
                '${p.wateringDueCount}',
                'Check water',
                Icons.water_drop_rounded,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _stat(String value, String label, IconData icon) => Row(
        children: [
          Icon(icon, color: Colors.white, size: 17),
          const SizedBox(width: 5),
          Text(
            '$value $label',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
              fontSize: 12,
            ),
          ),
        ],
      );

  Widget _todayCard(PlantProvider provider, Plant? attention) {
    if (attention == null && provider.wateringDueCount == 0) {
      return _infoCard(
        Icons.auto_awesome_rounded,
        'Plant Doctor tip',
        'Check the soil before watering. A calendar is a reminder, not a soil sensor.',
      );
    }

    if (attention != null) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(17),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _iconBubble(
                    Icons.health_and_safety_rounded,
                    AppColors.warning,
                  ),
                  const SizedBox(width: 11),
                  const Expanded(
                    child: Text(
                      'Needs attention',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  Text(
                    '${attention.healthScore}/100',
                    style: const TextStyle(
                      color: AppColors.warning,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 11),
              Text(
                '${attention.name} could use a health check.',
                style: const TextStyle(
                  fontSize: 14,
                  color: AppColors.subtext,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => _openPlant(attention.id),
                  icon: const Icon(Icons.arrow_forward_rounded),
                  label: const Text('Open plant report'),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return _infoCard(
      Icons.water_drop_rounded,
      'Watering check',
      '${provider.wateringDueCount} plant${provider.wateringDueCount == 1 ? '' : 's'} should have their soil checked today.',
    );
  }

  Widget _scanBanner() {
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: _openScanner,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppColors.mint,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Container(
              width: 54,
              height: 54,
              decoration: const BoxDecoration(
                color: AppColors.primary,
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.center_focus_strong_rounded,
                color: Colors.white,
              ),
            ),
            const SizedBox(width: 13),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Scan a plant',
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 16,
                    ),
                  ),
                  SizedBox(height: 3),
                  Text(
                    'Identify it and check visible symptoms with AI.',
                    style: TextStyle(
                      color: AppColors.subtext,
                      fontSize: 12,
                      height: 1.3,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.chevron_right_rounded,
              color: AppColors.primary,
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoCard(IconData icon, String title, String text) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(17),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _iconBubble(icon, AppColors.primary),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(
                    text,
                    style: const TextStyle(
                      color: AppColors.subtext,
                      height: 1.4,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _iconBubble(IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(9),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .12),
        shape: BoxShape.circle,
      ),
      child: Icon(icon, color: color),
    );
  }

  Widget _emptyState() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          children: [
            const Text('🌱', style: TextStyle(fontSize: 50)),
            const SizedBox(height: 10),
            const Text(
              'Your garden is empty',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 7),
            const Text(
              'Take a photo and let Plant Doctor meet your first plant.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.subtext, height: 1.4),
            ),
            const SizedBox(height: 18),
            ElevatedButton.icon(
              onPressed: _openScanner,
              icon: const Icon(Icons.camera_alt_rounded),
              label: const Text('Scan my first plant'),
            ),
          ],
        ),
      ),
    );
  }

  void _openScanner() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const CameraScreen()),
    );
  }

  void _openPlant(String id) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PlantDetailScreen(plantId: id)),
    );
  }
}
