# Plant Doctor — Ads

The ad code is intentionally isolated:

- `lib/services/ad_helper.dart` — test ad unit IDs
- `lib/services/ad_service.dart` — interstitial lifecycle and frequency
- `lib/widgets/plant_doctor_banner_ad.dart` — banner widget

The app uses:
- One banner on Home.
- One interstitial after 5 successful analyses (plant identification or plant check-up).
- No ad while the camera is being used.

## Test locally

From the `flutter` folder:

```bash
flutter clean
flutter pub get
flutter analyze
flutter run
```

The project currently uses Google's official test ad IDs. Replace them only when the app is ready for real AdMob publishing.

## GitHub

Push the **`plant-doctor`** repository root, not the `flutter` folder by itself.

The included GitHub Actions workflow is:

`.github/workflows/flutter_android.yml`

It runs Flutter analysis and builds the Android APK.
