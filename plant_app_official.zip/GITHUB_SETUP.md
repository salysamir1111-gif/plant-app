# Plant Doctor — GitHub + Ads

## Project structure

- `flutter/` — Flutter mobile app
- `flutter/lib/services/ad_helper.dart` — AdMob test IDs
- `flutter/lib/services/ad_service.dart` — interstitial ad manager
- `flutter/lib/widgets/plant_doctor_banner_ad.dart` — banner widget
- `flutter/lib/screens/home_screen.dart` — banner placement
- `flutter/lib/screens/camera_screen.dart` — analysis counter / interstitial trigger
- `flutter/android/app/src/main/AndroidManifest.xml` — Android AdMob App ID
- `backend/` — backend service
- `frontend/` — separate frontend

## Run locally

Open a terminal in `plant-doctor/flutter`:

```bash
flutter pub get
flutter analyze
flutter run
```

For Android:

```bash
flutter devices
flutter run -d <YOUR_ANDROID_DEVICE_ID>
```

## GitHub repository

1. Create a new repository on GitHub, for example `plant-doctor`.
2. Upload the contents of this `plant-doctor` folder.
3. Or use Git from the folder:

```bash
git init
git add .
git commit -m "Plant Doctor with balanced AdMob ads"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/plant-doctor.git
git push -u origin main
```

Your repository URL will then be:

`https://github.com/YOUR_USERNAME/plant-doctor`

## Build the Android app on GitHub

GitHub itself does not open the Flutter Android UI like an emulator. GitHub Actions can build the APK for you.

A workflow can run `flutter analyze` and `flutter build apk --release` whenever you push code. The generated APK can be uploaded as a GitHub Actions artifact.

## GitHub Pages / website URL

GitHub Pages is for web output. AdMob's `google_mobile_ads` Flutter plugin supports Android and iOS, not Flutter Web. Therefore the Android AdMob code should not be treated as a web advertising solution.

For a live Flutter Web version, first make the app web-compatible and disable/replace the mobile-only AdMob widgets/services on web. Then:

```bash
flutter build web
```

The web build is placed in `build/web`.

GitHub Pages URLs normally look like:

`https://YOUR_USERNAME.github.io/plant-doctor/`

## AdMob before publishing

The current IDs are Google's test IDs. Keep them while developing. Before release, create your own AdMob app/ad units and replace the test IDs. Do not click your own production ads.
